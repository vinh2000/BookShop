﻿namespace GUI
{
    partial class frmNhanVien
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmNhanVien));
            this.tabQLQuyen = new System.Windows.Forms.TabPage();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.lsvQuyen = new System.Windows.Forms.ListView();
            this.clm_MaNV = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clm_TenNV = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clm_Quyen = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel21 = new System.Windows.Forms.Panel();
            this.btn_SuaQuyen = new System.Windows.Forms.Button();
            this.imgList = new System.Windows.Forms.ImageList(this.components);
            this.btn_LMNV = new System.Windows.Forms.Button();
            this.panel22 = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.panel45 = new System.Windows.Forms.Panel();
            this.cmb_Quyen = new System.Windows.Forms.ComboBox();
            this.label21 = new System.Windows.Forms.Label();
            this.panel31 = new System.Windows.Forms.Panel();
            this.txt_TenNV = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.panel32 = new System.Windows.Forms.Panel();
            this.txt_MaNV = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.panel33 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.panel34 = new System.Windows.Forms.Panel();
            this.txt_TimNV = new System.Windows.Forms.TextBox();
            this.btn_TimNV = new System.Windows.Forms.Button();
            this.tabNhanVien = new System.Windows.Forms.TabControl();
            this.tabQLNhanVien = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.lsvNhanVien = new System.Windows.Forms.ListView();
            this.clmMaNV = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmTenDangNhap = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmHoTen = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmNgaySinh = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmGioiTinh = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmSDT = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmDiaChi = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel28 = new System.Windows.Forms.Panel();
            this.btnThemNV = new System.Windows.Forms.Button();
            this.btnSuaNV = new System.Windows.Forms.Button();
            this.btnXoaNV = new System.Windows.Forms.Button();
            this.btnLMNV = new System.Windows.Forms.Button();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.btnDatLaiMK = new System.Windows.Forms.Button();
            this.panel44 = new System.Windows.Forms.Panel();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.panel43 = new System.Windows.Forms.Panel();
            this.txtSDT = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.panel42 = new System.Windows.Forms.Panel();
            this.dtpNgaySinh = new System.Windows.Forms.DateTimePicker();
            this.label15 = new System.Windows.Forms.Label();
            this.panel41 = new System.Windows.Forms.Panel();
            this.radNu = new System.Windows.Forms.RadioButton();
            this.radNam = new System.Windows.Forms.RadioButton();
            this.label14 = new System.Windows.Forms.Label();
            this.panel40 = new System.Windows.Forms.Panel();
            this.txtHoTen = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.panel36 = new System.Windows.Forms.Panel();
            this.txtTenDangNhap = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.panel37 = new System.Windows.Forms.Panel();
            this.txtMaNV = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.panel38 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.panel39 = new System.Windows.Forms.Panel();
            this.txtTimNV = new System.Windows.Forms.TextBox();
            this.btnTimNV = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.btnTimSach = new System.Windows.Forms.Button();
            this.txtTimSach = new System.Windows.Forms.TextBox();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel10 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.txtMaSach = new System.Windows.Forms.TextBox();
            this.panel11 = new System.Windows.Forms.Panel();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTenSach = new System.Windows.Forms.TextBox();
            this.panel12 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.numGiaBan = new System.Windows.Forms.NumericUpDown();
            this.panel13 = new System.Windows.Forms.Panel();
            this.label5 = new System.Windows.Forms.Label();
            this.numNamXB = new System.Windows.Forms.NumericUpDown();
            this.panel14 = new System.Windows.Forms.Panel();
            this.label6 = new System.Windows.Forms.Label();
            this.numSoLuong = new System.Windows.Forms.NumericUpDown();
            this.panel15 = new System.Windows.Forms.Panel();
            this.cmbNXB = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.cmbTL = new System.Windows.Forms.ComboBox();
            this.panel17 = new System.Windows.Forms.Panel();
            this.label9 = new System.Windows.Forms.Label();
            this.cmbTG = new System.Windows.Forms.ComboBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnLMSach = new System.Windows.Forms.Button();
            this.btnXoaSach = new System.Windows.Forms.Button();
            this.btnSuaSach = new System.Windows.Forms.Button();
            this.btnThemSach = new System.Windows.Forms.Button();
            this.panel6 = new System.Windows.Forms.Panel();
            this.clm_TenDangNhap = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.tabQLQuyen.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel45.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel33.SuspendLayout();
            this.panel34.SuspendLayout();
            this.tabNhanVien.SuspendLayout();
            this.tabQLNhanVien.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel35.SuspendLayout();
            this.panel44.SuspendLayout();
            this.panel43.SuspendLayout();
            this.panel42.SuspendLayout();
            this.panel41.SuspendLayout();
            this.panel40.SuspendLayout();
            this.panel36.SuspendLayout();
            this.panel37.SuspendLayout();
            this.panel38.SuspendLayout();
            this.panel39.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numGiaBan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNamXB)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSoLuong)).BeginInit();
            this.SuspendLayout();
            // 
            // tabQLQuyen
            // 
            this.tabQLQuyen.Controls.Add(this.panel18);
            this.tabQLQuyen.ImageIndex = 7;
            this.tabQLQuyen.Location = new System.Drawing.Point(4, 31);
            this.tabQLQuyen.Name = "tabQLQuyen";
            this.tabQLQuyen.Padding = new System.Windows.Forms.Padding(3);
            this.tabQLQuyen.Size = new System.Drawing.Size(1174, 638);
            this.tabQLQuyen.TabIndex = 1;
            this.tabQLQuyen.Text = "Quản Lí Quyền";
            this.tabQLQuyen.UseVisualStyleBackColor = true;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.panel19);
            this.panel18.Controls.Add(this.panel22);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel18.Location = new System.Drawing.Point(3, 3);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(1168, 632);
            this.panel18.TabIndex = 1;
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.panel20);
            this.panel19.Controls.Add(this.panel21);
            this.panel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel19.Location = new System.Drawing.Point(0, 0);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(740, 632);
            this.panel19.TabIndex = 0;
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.lsvQuyen);
            this.panel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel20.Location = new System.Drawing.Point(0, 49);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(740, 583);
            this.panel20.TabIndex = 1;
            // 
            // lsvQuyen
            // 
            this.lsvQuyen.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clm_MaNV,
            this.clm_TenDangNhap,
            this.clm_TenNV,
            this.clm_Quyen});
            this.lsvQuyen.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lsvQuyen.FullRowSelect = true;
            this.lsvQuyen.GridLines = true;
            this.lsvQuyen.HideSelection = false;
            this.lsvQuyen.Location = new System.Drawing.Point(0, 0);
            this.lsvQuyen.MultiSelect = false;
            this.lsvQuyen.Name = "lsvQuyen";
            this.lsvQuyen.Size = new System.Drawing.Size(740, 583);
            this.lsvQuyen.TabIndex = 0;
            this.lsvQuyen.TabStop = false;
            this.lsvQuyen.UseCompatibleStateImageBehavior = false;
            this.lsvQuyen.View = System.Windows.Forms.View.Details;
            this.lsvQuyen.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.lsvQuyen_ColumnClick);
            this.lsvQuyen.SelectedIndexChanged += new System.EventHandler(this.lsvQuyen_SelectedIndexChanged);
            // 
            // clm_MaNV
            // 
            this.clm_MaNV.Text = "Mã NV";
            this.clm_MaNV.Width = 99;
            // 
            // clm_TenNV
            // 
            this.clm_TenNV.Text = "Tên Nhân Viên";
            this.clm_TenNV.Width = 263;
            // 
            // clm_Quyen
            // 
            this.clm_Quyen.Text = "Quyền";
            this.clm_Quyen.Width = 173;
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.btn_SuaQuyen);
            this.panel21.Controls.Add(this.btn_LMNV);
            this.panel21.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel21.Location = new System.Drawing.Point(0, 0);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(740, 49);
            this.panel21.TabIndex = 0;
            // 
            // btn_SuaQuyen
            // 
            this.btn_SuaQuyen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_SuaQuyen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btn_SuaQuyen.FlatAppearance.BorderSize = 0;
            this.btn_SuaQuyen.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_SuaQuyen.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_SuaQuyen.ForeColor = System.Drawing.Color.White;
            this.btn_SuaQuyen.ImageIndex = 1;
            this.btn_SuaQuyen.ImageList = this.imgList;
            this.btn_SuaQuyen.Location = new System.Drawing.Point(502, 3);
            this.btn_SuaQuyen.Name = "btn_SuaQuyen";
            this.btn_SuaQuyen.Size = new System.Drawing.Size(113, 40);
            this.btn_SuaQuyen.TabIndex = 1;
            this.btn_SuaQuyen.Text = "Sửa";
            this.btn_SuaQuyen.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_SuaQuyen.UseVisualStyleBackColor = false;
            this.btn_SuaQuyen.Click += new System.EventHandler(this.btn_SuaQuyen_Click);
            // 
            // imgList
            // 
            this.imgList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgList.ImageStream")));
            this.imgList.TransparentColor = System.Drawing.Color.Transparent;
            this.imgList.Images.SetKeyName(0, "add.png");
            this.imgList.Images.SetKeyName(1, "edit.png");
            this.imgList.Images.SetKeyName(2, "bin.png");
            this.imgList.Images.SetKeyName(3, "delete.png");
            this.imgList.Images.SetKeyName(4, "search.png");
            this.imgList.Images.SetKeyName(5, "reset.png");
            this.imgList.Images.SetKeyName(6, "account.png");
            this.imgList.Images.SetKeyName(7, "permission.png");
            // 
            // btn_LMNV
            // 
            this.btn_LMNV.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_LMNV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btn_LMNV.FlatAppearance.BorderSize = 0;
            this.btn_LMNV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_LMNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_LMNV.ForeColor = System.Drawing.Color.White;
            this.btn_LMNV.ImageIndex = 3;
            this.btn_LMNV.ImageList = this.imgList;
            this.btn_LMNV.Location = new System.Drawing.Point(621, 3);
            this.btn_LMNV.Name = "btn_LMNV";
            this.btn_LMNV.Size = new System.Drawing.Size(113, 40);
            this.btn_LMNV.TabIndex = 3;
            this.btn_LMNV.Text = "Làm mới";
            this.btn_LMNV.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_LMNV.UseVisualStyleBackColor = false;
            this.btn_LMNV.Click += new System.EventHandler(this.btn_LMNV_Click);
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.panel23);
            this.panel22.Controls.Add(this.panel34);
            this.panel22.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel22.Location = new System.Drawing.Point(740, 0);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(428, 632);
            this.panel22.TabIndex = 1;
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.panel24);
            this.panel23.Controls.Add(this.panel33);
            this.panel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel23.Location = new System.Drawing.Point(0, 49);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(428, 583);
            this.panel23.TabIndex = 1;
            // 
            // panel24
            // 
            this.panel24.Controls.Add(this.panel45);
            this.panel24.Controls.Add(this.panel31);
            this.panel24.Controls.Add(this.panel32);
            this.panel24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel24.Location = new System.Drawing.Point(0, 45);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(428, 538);
            this.panel24.TabIndex = 0;
            // 
            // panel45
            // 
            this.panel45.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel45.Controls.Add(this.cmb_Quyen);
            this.panel45.Controls.Add(this.label21);
            this.panel45.Location = new System.Drawing.Point(6, 121);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(416, 38);
            this.panel45.TabIndex = 2;
            // 
            // cmb_Quyen
            // 
            this.cmb_Quyen.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmb_Quyen.FormattingEnabled = true;
            this.cmb_Quyen.Location = new System.Drawing.Point(117, 4);
            this.cmb_Quyen.Name = "cmb_Quyen";
            this.cmb_Quyen.Size = new System.Drawing.Size(296, 33);
            this.cmb_Quyen.TabIndex = 1;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(4, 7);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(72, 24);
            this.label21.TabIndex = 0;
            this.label21.Text = "Quyền:";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel31
            // 
            this.panel31.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel31.Controls.Add(this.txt_TenNV);
            this.panel31.Controls.Add(this.label16);
            this.panel31.Location = new System.Drawing.Point(6, 64);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(416, 38);
            this.panel31.TabIndex = 1;
            // 
            // txt_TenNV
            // 
            this.txt_TenNV.Enabled = false;
            this.txt_TenNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TenNV.Location = new System.Drawing.Point(117, 3);
            this.txt_TenNV.Name = "txt_TenNV";
            this.txt_TenNV.Size = new System.Drawing.Size(296, 30);
            this.txt_TenNV.TabIndex = 1;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(4, 7);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(81, 24);
            this.label16.TabIndex = 0;
            this.label16.Text = "Tên NV:";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel32
            // 
            this.panel32.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel32.Controls.Add(this.txt_MaNV);
            this.panel32.Controls.Add(this.label17);
            this.panel32.Location = new System.Drawing.Point(6, 7);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(416, 38);
            this.panel32.TabIndex = 0;
            // 
            // txt_MaNV
            // 
            this.txt_MaNV.Enabled = false;
            this.txt_MaNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_MaNV.Location = new System.Drawing.Point(117, 3);
            this.txt_MaNV.Name = "txt_MaNV";
            this.txt_MaNV.Size = new System.Drawing.Size(296, 30);
            this.txt_MaNV.TabIndex = 1;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(4, 7);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(73, 24);
            this.label17.TabIndex = 0;
            this.label17.Text = "Mã NV:";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel33
            // 
            this.panel33.Controls.Add(this.label18);
            this.panel33.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel33.Location = new System.Drawing.Point(0, 0);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(428, 45);
            this.panel33.TabIndex = 0;
            // 
            // label18
            // 
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(0, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(428, 45);
            this.label18.TabIndex = 0;
            this.label18.Text = "Thông tin chi tiết";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel34
            // 
            this.panel34.Controls.Add(this.txt_TimNV);
            this.panel34.Controls.Add(this.btn_TimNV);
            this.panel34.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel34.Location = new System.Drawing.Point(0, 0);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(428, 49);
            this.panel34.TabIndex = 0;
            // 
            // txt_TimNV
            // 
            this.txt_TimNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txt_TimNV.Location = new System.Drawing.Point(14, 13);
            this.txt_TimNV.Name = "txt_TimNV";
            this.txt_TimNV.Size = new System.Drawing.Size(292, 30);
            this.txt_TimNV.TabIndex = 0;
            this.txt_TimNV.TextChanged += new System.EventHandler(this.txt_TimNV_TextChanged);
            // 
            // btn_TimNV
            // 
            this.btn_TimNV.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btn_TimNV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btn_TimNV.FlatAppearance.BorderSize = 0;
            this.btn_TimNV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_TimNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_TimNV.ForeColor = System.Drawing.Color.White;
            this.btn_TimNV.ImageIndex = 4;
            this.btn_TimNV.ImageList = this.imgList;
            this.btn_TimNV.Location = new System.Drawing.Point(312, 3);
            this.btn_TimNV.Name = "btn_TimNV";
            this.btn_TimNV.Size = new System.Drawing.Size(113, 40);
            this.btn_TimNV.TabIndex = 1;
            this.btn_TimNV.Text = "Tìm";
            this.btn_TimNV.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_TimNV.UseVisualStyleBackColor = false;
            this.btn_TimNV.Click += new System.EventHandler(this.btn_TimNV_Click);
            // 
            // tabNhanVien
            // 
            this.tabNhanVien.Controls.Add(this.tabQLNhanVien);
            this.tabNhanVien.Controls.Add(this.tabQLQuyen);
            this.tabNhanVien.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabNhanVien.ImageList = this.imgList;
            this.tabNhanVien.Location = new System.Drawing.Point(0, 0);
            this.tabNhanVien.Name = "tabNhanVien";
            this.tabNhanVien.SelectedIndex = 0;
            this.tabNhanVien.Size = new System.Drawing.Size(1182, 673);
            this.tabNhanVien.TabIndex = 1;
            // 
            // tabQLNhanVien
            // 
            this.tabQLNhanVien.Controls.Add(this.panel1);
            this.tabQLNhanVien.ImageIndex = 6;
            this.tabQLNhanVien.Location = new System.Drawing.Point(4, 31);
            this.tabQLNhanVien.Name = "tabQLNhanVien";
            this.tabQLNhanVien.Padding = new System.Windows.Forms.Padding(3);
            this.tabQLNhanVien.Size = new System.Drawing.Size(1174, 638);
            this.tabQLNhanVien.TabIndex = 0;
            this.tabQLNhanVien.Text = "Nhân Viên";
            this.tabQLNhanVien.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel25);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1168, 632);
            this.panel1.TabIndex = 0;
            // 
            // panel25
            // 
            this.panel25.Controls.Add(this.panel26);
            this.panel25.Controls.Add(this.panel29);
            this.panel25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel25.Location = new System.Drawing.Point(0, 0);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(1168, 632);
            this.panel25.TabIndex = 2;
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.panel27);
            this.panel26.Controls.Add(this.panel28);
            this.panel26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel26.Location = new System.Drawing.Point(0, 0);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(740, 632);
            this.panel26.TabIndex = 0;
            // 
            // panel27
            // 
            this.panel27.Controls.Add(this.lsvNhanVien);
            this.panel27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel27.Location = new System.Drawing.Point(0, 49);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(740, 583);
            this.panel27.TabIndex = 1;
            // 
            // lsvNhanVien
            // 
            this.lsvNhanVien.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clmMaNV,
            this.clmTenDangNhap,
            this.clmHoTen,
            this.clmNgaySinh,
            this.clmGioiTinh,
            this.clmSDT,
            this.clmDiaChi});
            this.lsvNhanVien.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lsvNhanVien.FullRowSelect = true;
            this.lsvNhanVien.GridLines = true;
            this.lsvNhanVien.HideSelection = false;
            this.lsvNhanVien.Location = new System.Drawing.Point(0, 0);
            this.lsvNhanVien.MultiSelect = false;
            this.lsvNhanVien.Name = "lsvNhanVien";
            this.lsvNhanVien.Size = new System.Drawing.Size(740, 583);
            this.lsvNhanVien.TabIndex = 0;
            this.lsvNhanVien.TabStop = false;
            this.lsvNhanVien.UseCompatibleStateImageBehavior = false;
            this.lsvNhanVien.View = System.Windows.Forms.View.Details;
            this.lsvNhanVien.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.lsvNhanVien_ColumnClick);
            this.lsvNhanVien.SelectedIndexChanged += new System.EventHandler(this.lsvNhanVien_SelectedIndexChanged);
            // 
            // clmMaNV
            // 
            this.clmMaNV.Text = "Mã NV";
            this.clmMaNV.Width = 79;
            // 
            // clmTenDangNhap
            // 
            this.clmTenDangNhap.Text = "Tên Đăng Nhập";
            this.clmTenDangNhap.Width = 166;
            // 
            // clmHoTen
            // 
            this.clmHoTen.Text = "Họ Tên";
            this.clmHoTen.Width = 185;
            // 
            // clmNgaySinh
            // 
            this.clmNgaySinh.DisplayIndex = 4;
            this.clmNgaySinh.Text = "Ngày Sinh";
            this.clmNgaySinh.Width = 129;
            // 
            // clmGioiTinh
            // 
            this.clmGioiTinh.DisplayIndex = 3;
            this.clmGioiTinh.Text = "Giới Tính";
            this.clmGioiTinh.Width = 108;
            // 
            // clmSDT
            // 
            this.clmSDT.Text = "Số Điện Thoại";
            this.clmSDT.Width = 120;
            // 
            // clmDiaChi
            // 
            this.clmDiaChi.Text = "Địa Chỉ";
            this.clmDiaChi.Width = 250;
            // 
            // panel28
            // 
            this.panel28.Controls.Add(this.btnThemNV);
            this.panel28.Controls.Add(this.btnSuaNV);
            this.panel28.Controls.Add(this.btnXoaNV);
            this.panel28.Controls.Add(this.btnLMNV);
            this.panel28.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel28.Location = new System.Drawing.Point(0, 0);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(740, 49);
            this.panel28.TabIndex = 0;
            // 
            // btnThemNV
            // 
            this.btnThemNV.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThemNV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnThemNV.FlatAppearance.BorderSize = 0;
            this.btnThemNV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemNV.ForeColor = System.Drawing.Color.White;
            this.btnThemNV.ImageIndex = 0;
            this.btnThemNV.ImageList = this.imgList;
            this.btnThemNV.Location = new System.Drawing.Point(264, 3);
            this.btnThemNV.Name = "btnThemNV";
            this.btnThemNV.Size = new System.Drawing.Size(113, 40);
            this.btnThemNV.TabIndex = 0;
            this.btnThemNV.Text = "Thêm";
            this.btnThemNV.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnThemNV.UseVisualStyleBackColor = false;
            this.btnThemNV.Click += new System.EventHandler(this.btnThemNV_Click);
            // 
            // btnSuaNV
            // 
            this.btnSuaNV.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSuaNV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnSuaNV.FlatAppearance.BorderSize = 0;
            this.btnSuaNV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSuaNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuaNV.ForeColor = System.Drawing.Color.White;
            this.btnSuaNV.ImageIndex = 1;
            this.btnSuaNV.ImageList = this.imgList;
            this.btnSuaNV.Location = new System.Drawing.Point(383, 3);
            this.btnSuaNV.Name = "btnSuaNV";
            this.btnSuaNV.Size = new System.Drawing.Size(113, 40);
            this.btnSuaNV.TabIndex = 1;
            this.btnSuaNV.Text = "Sửa";
            this.btnSuaNV.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSuaNV.UseVisualStyleBackColor = false;
            this.btnSuaNV.Click += new System.EventHandler(this.btnSuaNV_Click);
            // 
            // btnXoaNV
            // 
            this.btnXoaNV.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnXoaNV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnXoaNV.FlatAppearance.BorderSize = 0;
            this.btnXoaNV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoaNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaNV.ForeColor = System.Drawing.Color.White;
            this.btnXoaNV.ImageIndex = 2;
            this.btnXoaNV.ImageList = this.imgList;
            this.btnXoaNV.Location = new System.Drawing.Point(502, 3);
            this.btnXoaNV.Name = "btnXoaNV";
            this.btnXoaNV.Size = new System.Drawing.Size(113, 40);
            this.btnXoaNV.TabIndex = 2;
            this.btnXoaNV.Text = "Xóa";
            this.btnXoaNV.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnXoaNV.UseVisualStyleBackColor = false;
            this.btnXoaNV.Click += new System.EventHandler(this.btnXoaNV_Click);
            // 
            // btnLMNV
            // 
            this.btnLMNV.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLMNV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnLMNV.FlatAppearance.BorderSize = 0;
            this.btnLMNV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLMNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLMNV.ForeColor = System.Drawing.Color.White;
            this.btnLMNV.ImageIndex = 3;
            this.btnLMNV.ImageList = this.imgList;
            this.btnLMNV.Location = new System.Drawing.Point(621, 3);
            this.btnLMNV.Name = "btnLMNV";
            this.btnLMNV.Size = new System.Drawing.Size(113, 40);
            this.btnLMNV.TabIndex = 3;
            this.btnLMNV.Text = "Làm mới";
            this.btnLMNV.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnLMNV.UseVisualStyleBackColor = false;
            this.btnLMNV.Click += new System.EventHandler(this.btnLMNV_Click);
            // 
            // panel29
            // 
            this.panel29.Controls.Add(this.panel30);
            this.panel29.Controls.Add(this.panel39);
            this.panel29.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel29.Location = new System.Drawing.Point(740, 0);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(428, 632);
            this.panel29.TabIndex = 1;
            // 
            // panel30
            // 
            this.panel30.Controls.Add(this.panel35);
            this.panel30.Controls.Add(this.panel38);
            this.panel30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel30.Location = new System.Drawing.Point(0, 49);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(428, 583);
            this.panel30.TabIndex = 1;
            // 
            // panel35
            // 
            this.panel35.Controls.Add(this.btnDatLaiMK);
            this.panel35.Controls.Add(this.panel44);
            this.panel35.Controls.Add(this.panel43);
            this.panel35.Controls.Add(this.panel42);
            this.panel35.Controls.Add(this.panel41);
            this.panel35.Controls.Add(this.panel40);
            this.panel35.Controls.Add(this.panel36);
            this.panel35.Controls.Add(this.panel37);
            this.panel35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel35.Location = new System.Drawing.Point(0, 45);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(428, 538);
            this.panel35.TabIndex = 0;
            // 
            // btnDatLaiMK
            // 
            this.btnDatLaiMK.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDatLaiMK.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnDatLaiMK.FlatAppearance.BorderSize = 0;
            this.btnDatLaiMK.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDatLaiMK.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDatLaiMK.ForeColor = System.Drawing.Color.White;
            this.btnDatLaiMK.ImageIndex = 5;
            this.btnDatLaiMK.ImageList = this.imgList;
            this.btnDatLaiMK.Location = new System.Drawing.Point(186, 448);
            this.btnDatLaiMK.Name = "btnDatLaiMK";
            this.btnDatLaiMK.Size = new System.Drawing.Size(237, 40);
            this.btnDatLaiMK.TabIndex = 7;
            this.btnDatLaiMK.Text = "ĐẶT LẠI MẬT KHẨU";
            this.btnDatLaiMK.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnDatLaiMK.UseVisualStyleBackColor = false;
            this.btnDatLaiMK.Click += new System.EventHandler(this.btnDatLaiMK_Click);
            // 
            // panel44
            // 
            this.panel44.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel44.Controls.Add(this.txtDiaChi);
            this.panel44.Controls.Add(this.label20);
            this.panel44.Location = new System.Drawing.Point(6, 349);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(416, 93);
            this.panel44.TabIndex = 6;
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Enabled = false;
            this.txtDiaChi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiaChi.Location = new System.Drawing.Point(117, 0);
            this.txtDiaChi.Multiline = true;
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(296, 90);
            this.txtDiaChi.TabIndex = 1;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(4, 7);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(75, 24);
            this.label20.TabIndex = 0;
            this.label20.Text = "Địa Chỉ:";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel43
            // 
            this.panel43.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel43.Controls.Add(this.txtSDT);
            this.panel43.Controls.Add(this.label19);
            this.panel43.Location = new System.Drawing.Point(6, 292);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(416, 38);
            this.panel43.TabIndex = 5;
            // 
            // txtSDT
            // 
            this.txtSDT.Enabled = false;
            this.txtSDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSDT.Location = new System.Drawing.Point(117, 3);
            this.txtSDT.Name = "txtSDT";
            this.txtSDT.Size = new System.Drawing.Size(296, 30);
            this.txtSDT.TabIndex = 1;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(4, 7);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(52, 24);
            this.label19.TabIndex = 0;
            this.label19.Text = "SĐT:";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel42
            // 
            this.panel42.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel42.Controls.Add(this.dtpNgaySinh);
            this.panel42.Controls.Add(this.label15);
            this.panel42.Location = new System.Drawing.Point(6, 235);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(416, 38);
            this.panel42.TabIndex = 4;
            // 
            // dtpNgaySinh
            // 
            this.dtpNgaySinh.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpNgaySinh.CustomFormat = "dd-MM-yyyy";
            this.dtpNgaySinh.Enabled = false;
            this.dtpNgaySinh.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dtpNgaySinh.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dtpNgaySinh.Location = new System.Drawing.Point(117, 5);
            this.dtpNgaySinh.Name = "dtpNgaySinh";
            this.dtpNgaySinh.Size = new System.Drawing.Size(296, 30);
            this.dtpNgaySinh.TabIndex = 1;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(4, 7);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(102, 24);
            this.label15.TabIndex = 0;
            this.label15.Text = "Ngày Sinh:";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel41
            // 
            this.panel41.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel41.Controls.Add(this.radNu);
            this.panel41.Controls.Add(this.radNam);
            this.panel41.Controls.Add(this.label14);
            this.panel41.Location = new System.Drawing.Point(6, 178);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(416, 38);
            this.panel41.TabIndex = 3;
            // 
            // radNu
            // 
            this.radNu.AutoSize = true;
            this.radNu.Enabled = false;
            this.radNu.Location = new System.Drawing.Point(219, 5);
            this.radNu.Name = "radNu";
            this.radNu.Size = new System.Drawing.Size(56, 28);
            this.radNu.TabIndex = 2;
            this.radNu.TabStop = true;
            this.radNu.Text = "Nữ";
            this.radNu.UseVisualStyleBackColor = true;
            // 
            // radNam
            // 
            this.radNam.AutoSize = true;
            this.radNam.Enabled = false;
            this.radNam.Location = new System.Drawing.Point(117, 5);
            this.radNam.Name = "radNam";
            this.radNam.Size = new System.Drawing.Size(71, 28);
            this.radNam.TabIndex = 1;
            this.radNam.TabStop = true;
            this.radNam.Text = "Nam";
            this.radNam.UseVisualStyleBackColor = true;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(4, 7);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(91, 24);
            this.label14.TabIndex = 0;
            this.label14.Text = "Giới Tính:";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel40
            // 
            this.panel40.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel40.Controls.Add(this.txtHoTen);
            this.panel40.Controls.Add(this.label13);
            this.panel40.Location = new System.Drawing.Point(6, 121);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(416, 38);
            this.panel40.TabIndex = 2;
            // 
            // txtHoTen
            // 
            this.txtHoTen.Enabled = false;
            this.txtHoTen.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtHoTen.Location = new System.Drawing.Point(117, 3);
            this.txtHoTen.Name = "txtHoTen";
            this.txtHoTen.Size = new System.Drawing.Size(296, 30);
            this.txtHoTen.TabIndex = 1;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(4, 7);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(79, 24);
            this.label13.TabIndex = 0;
            this.label13.Text = "Họ Tên:";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel36
            // 
            this.panel36.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel36.Controls.Add(this.txtTenDangNhap);
            this.panel36.Controls.Add(this.label10);
            this.panel36.Location = new System.Drawing.Point(6, 64);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(416, 38);
            this.panel36.TabIndex = 1;
            // 
            // txtTenDangNhap
            // 
            this.txtTenDangNhap.Enabled = false;
            this.txtTenDangNhap.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenDangNhap.Location = new System.Drawing.Point(117, 3);
            this.txtTenDangNhap.Name = "txtTenDangNhap";
            this.txtTenDangNhap.Size = new System.Drawing.Size(296, 30);
            this.txtTenDangNhap.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(4, 7);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(81, 24);
            this.label10.TabIndex = 0;
            this.label10.Text = "Tên ĐN:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel37
            // 
            this.panel37.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel37.Controls.Add(this.txtMaNV);
            this.panel37.Controls.Add(this.label11);
            this.panel37.Location = new System.Drawing.Point(6, 7);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(416, 38);
            this.panel37.TabIndex = 0;
            // 
            // txtMaNV
            // 
            this.txtMaNV.Enabled = false;
            this.txtMaNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaNV.Location = new System.Drawing.Point(117, 3);
            this.txtMaNV.Name = "txtMaNV";
            this.txtMaNV.ReadOnly = true;
            this.txtMaNV.Size = new System.Drawing.Size(296, 30);
            this.txtMaNV.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(4, 7);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(73, 24);
            this.label11.TabIndex = 0;
            this.label11.Text = "Mã NV:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel38
            // 
            this.panel38.Controls.Add(this.label12);
            this.panel38.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel38.Location = new System.Drawing.Point(0, 0);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(428, 45);
            this.panel38.TabIndex = 0;
            // 
            // label12
            // 
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(0, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(428, 45);
            this.label12.TabIndex = 0;
            this.label12.Text = "Thông tin chi tiết";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel39
            // 
            this.panel39.Controls.Add(this.txtTimNV);
            this.panel39.Controls.Add(this.btnTimNV);
            this.panel39.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel39.Location = new System.Drawing.Point(0, 0);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(428, 49);
            this.panel39.TabIndex = 0;
            // 
            // txtTimNV
            // 
            this.txtTimNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTimNV.Location = new System.Drawing.Point(14, 13);
            this.txtTimNV.Name = "txtTimNV";
            this.txtTimNV.Size = new System.Drawing.Size(292, 30);
            this.txtTimNV.TabIndex = 0;
            this.txtTimNV.TextChanged += new System.EventHandler(this.txtTimNV_TextChanged);
            // 
            // btnTimNV
            // 
            this.btnTimNV.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTimNV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnTimNV.FlatAppearance.BorderSize = 0;
            this.btnTimNV.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTimNV.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimNV.ForeColor = System.Drawing.Color.White;
            this.btnTimNV.ImageIndex = 4;
            this.btnTimNV.ImageList = this.imgList;
            this.btnTimNV.Location = new System.Drawing.Point(312, 3);
            this.btnTimNV.Name = "btnTimNV";
            this.btnTimNV.Size = new System.Drawing.Size(113, 40);
            this.btnTimNV.TabIndex = 1;
            this.btnTimNV.Text = "Tìm";
            this.btnTimNV.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnTimNV.UseVisualStyleBackColor = false;
            this.btnTimNV.Click += new System.EventHandler(this.btnTimNV_Click);
            // 
            // panel3
            // 
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(740, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(428, 632);
            this.panel3.TabIndex = 1;
            // 
            // panel5
            // 
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(428, 49);
            this.panel5.TabIndex = 0;
            // 
            // btnTimSach
            // 
            this.btnTimSach.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTimSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnTimSach.FlatAppearance.BorderSize = 0;
            this.btnTimSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTimSach.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimSach.ForeColor = System.Drawing.Color.White;
            this.btnTimSach.ImageIndex = 3;
            this.btnTimSach.Location = new System.Drawing.Point(312, 3);
            this.btnTimSach.Name = "btnTimSach";
            this.btnTimSach.Size = new System.Drawing.Size(113, 40);
            this.btnTimSach.TabIndex = 1;
            this.btnTimSach.Text = "Tìm";
            this.btnTimSach.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnTimSach.UseVisualStyleBackColor = false;
            // 
            // txtTimSach
            // 
            this.txtTimSach.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTimSach.Location = new System.Drawing.Point(14, 13);
            this.txtTimSach.Name = "txtTimSach";
            this.txtTimSach.Size = new System.Drawing.Size(292, 30);
            this.txtTimSach.TabIndex = 0;
            // 
            // panel7
            // 
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(0, 49);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(428, 583);
            this.panel7.TabIndex = 1;
            // 
            // panel8
            // 
            this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(428, 45);
            this.panel8.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(428, 45);
            this.label1.TabIndex = 0;
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel9
            // 
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(0, 45);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(428, 538);
            this.panel9.TabIndex = 0;
            // 
            // panel10
            // 
            this.panel10.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel10.Location = new System.Drawing.Point(6, 7);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(416, 38);
            this.panel10.TabIndex = 0;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 24);
            this.label2.TabIndex = 0;
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtMaSach
            // 
            this.txtMaSach.Enabled = false;
            this.txtMaSach.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaSach.Location = new System.Drawing.Point(117, 3);
            this.txtMaSach.Name = "txtMaSach";
            this.txtMaSach.Size = new System.Drawing.Size(296, 30);
            this.txtMaSach.TabIndex = 1;
            // 
            // panel11
            // 
            this.panel11.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel11.Location = new System.Drawing.Point(6, 62);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(416, 38);
            this.panel11.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 24);
            this.label3.TabIndex = 0;
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // txtTenSach
            // 
            this.txtTenSach.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenSach.Location = new System.Drawing.Point(117, 3);
            this.txtTenSach.Name = "txtTenSach";
            this.txtTenSach.Size = new System.Drawing.Size(296, 30);
            this.txtTenSach.TabIndex = 1;
            // 
            // panel12
            // 
            this.panel12.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel12.Location = new System.Drawing.Point(6, 117);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(416, 38);
            this.panel12.TabIndex = 2;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(4, 7);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 24);
            this.label4.TabIndex = 0;
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // numGiaBan
            // 
            this.numGiaBan.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numGiaBan.Location = new System.Drawing.Point(117, 4);
            this.numGiaBan.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.numGiaBan.Name = "numGiaBan";
            this.numGiaBan.Size = new System.Drawing.Size(155, 30);
            this.numGiaBan.TabIndex = 2;
            this.numGiaBan.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numGiaBan.ThousandsSeparator = true;
            // 
            // panel13
            // 
            this.panel13.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel13.Location = new System.Drawing.Point(6, 172);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(416, 38);
            this.panel13.TabIndex = 3;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(4, 7);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 24);
            this.label5.TabIndex = 0;
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // numNamXB
            // 
            this.numNamXB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numNamXB.Location = new System.Drawing.Point(117, 3);
            this.numNamXB.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.numNamXB.Name = "numNamXB";
            this.numNamXB.Size = new System.Drawing.Size(155, 30);
            this.numNamXB.TabIndex = 3;
            this.numNamXB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numNamXB.ThousandsSeparator = true;
            // 
            // panel14
            // 
            this.panel14.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel14.Location = new System.Drawing.Point(6, 227);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(416, 38);
            this.panel14.TabIndex = 4;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(4, 7);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 24);
            this.label6.TabIndex = 0;
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // numSoLuong
            // 
            this.numSoLuong.Enabled = false;
            this.numSoLuong.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numSoLuong.Location = new System.Drawing.Point(117, 3);
            this.numSoLuong.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.numSoLuong.Name = "numSoLuong";
            this.numSoLuong.Size = new System.Drawing.Size(155, 30);
            this.numSoLuong.TabIndex = 4;
            this.numSoLuong.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numSoLuong.ThousandsSeparator = true;
            // 
            // panel15
            // 
            this.panel15.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel15.Location = new System.Drawing.Point(6, 282);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(416, 38);
            this.panel15.TabIndex = 5;
            // 
            // cmbNXB
            // 
            this.cmbNXB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbNXB.FormattingEnabled = true;
            this.cmbNXB.Location = new System.Drawing.Point(117, 3);
            this.cmbNXB.Name = "cmbNXB";
            this.cmbNXB.Size = new System.Drawing.Size(296, 33);
            this.cmbNXB.TabIndex = 1;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(4, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 24);
            this.label7.TabIndex = 0;
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel16
            // 
            this.panel16.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel16.Location = new System.Drawing.Point(6, 337);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(416, 38);
            this.panel16.TabIndex = 6;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(4, 7);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 24);
            this.label8.TabIndex = 0;
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cmbTL
            // 
            this.cmbTL.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTL.FormattingEnabled = true;
            this.cmbTL.Location = new System.Drawing.Point(117, 2);
            this.cmbTL.Name = "cmbTL";
            this.cmbTL.Size = new System.Drawing.Size(296, 33);
            this.cmbTL.TabIndex = 1;
            // 
            // panel17
            // 
            this.panel17.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel17.Location = new System.Drawing.Point(6, 392);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(416, 38);
            this.panel17.TabIndex = 7;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(4, 7);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 24);
            this.label9.TabIndex = 0;
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cmbTG
            // 
            this.cmbTG.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTG.FormattingEnabled = true;
            this.cmbTG.Location = new System.Drawing.Point(117, 3);
            this.cmbTG.Name = "cmbTG";
            this.cmbTG.Size = new System.Drawing.Size(296, 33);
            this.cmbTG.TabIndex = 1;
            // 
            // panel2
            // 
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(740, 632);
            this.panel2.TabIndex = 0;
            // 
            // panel4
            // 
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(740, 49);
            this.panel4.TabIndex = 0;
            // 
            // btnLMSach
            // 
            this.btnLMSach.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLMSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnLMSach.FlatAppearance.BorderSize = 0;
            this.btnLMSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLMSach.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLMSach.ForeColor = System.Drawing.Color.White;
            this.btnLMSach.ImageIndex = 4;
            this.btnLMSach.Location = new System.Drawing.Point(621, 3);
            this.btnLMSach.Name = "btnLMSach";
            this.btnLMSach.Size = new System.Drawing.Size(113, 40);
            this.btnLMSach.TabIndex = 3;
            this.btnLMSach.Text = "Làm mới";
            this.btnLMSach.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnLMSach.UseVisualStyleBackColor = false;
            // 
            // btnXoaSach
            // 
            this.btnXoaSach.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnXoaSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnXoaSach.FlatAppearance.BorderSize = 0;
            this.btnXoaSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoaSach.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaSach.ForeColor = System.Drawing.Color.White;
            this.btnXoaSach.ImageIndex = 2;
            this.btnXoaSach.Location = new System.Drawing.Point(502, 3);
            this.btnXoaSach.Name = "btnXoaSach";
            this.btnXoaSach.Size = new System.Drawing.Size(113, 40);
            this.btnXoaSach.TabIndex = 2;
            this.btnXoaSach.Text = "Xóa";
            this.btnXoaSach.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnXoaSach.UseVisualStyleBackColor = false;
            // 
            // btnSuaSach
            // 
            this.btnSuaSach.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSuaSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnSuaSach.FlatAppearance.BorderSize = 0;
            this.btnSuaSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSuaSach.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuaSach.ForeColor = System.Drawing.Color.White;
            this.btnSuaSach.ImageIndex = 1;
            this.btnSuaSach.Location = new System.Drawing.Point(383, 3);
            this.btnSuaSach.Name = "btnSuaSach";
            this.btnSuaSach.Size = new System.Drawing.Size(113, 40);
            this.btnSuaSach.TabIndex = 1;
            this.btnSuaSach.Text = "Sửa";
            this.btnSuaSach.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSuaSach.UseVisualStyleBackColor = false;
            // 
            // btnThemSach
            // 
            this.btnThemSach.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThemSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnThemSach.FlatAppearance.BorderSize = 0;
            this.btnThemSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemSach.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemSach.ForeColor = System.Drawing.Color.White;
            this.btnThemSach.ImageIndex = 0;
            this.btnThemSach.Location = new System.Drawing.Point(264, 3);
            this.btnThemSach.Name = "btnThemSach";
            this.btnThemSach.Size = new System.Drawing.Size(113, 40);
            this.btnThemSach.TabIndex = 0;
            this.btnThemSach.Text = "Thêm";
            this.btnThemSach.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnThemSach.UseVisualStyleBackColor = false;
            // 
            // panel6
            // 
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(0, 49);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(740, 583);
            this.panel6.TabIndex = 1;
            // 
            // clm_TenDangNhap
            // 
            this.clm_TenDangNhap.Text = "Tên đăng nhập";
            this.clm_TenDangNhap.Width = 180;
            // 
            // frmNhanVien
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1182, 673);
            this.Controls.Add(this.tabNhanVien);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(1200, 720);
            this.Name = "frmNhanVien";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "QUẢN LÍ NHÂN VIÊN";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmNhanVien_Load);
            this.tabQLQuyen.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel24.ResumeLayout(false);
            this.panel45.ResumeLayout(false);
            this.panel45.PerformLayout();
            this.panel31.ResumeLayout(false);
            this.panel31.PerformLayout();
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.panel33.ResumeLayout(false);
            this.panel34.ResumeLayout(false);
            this.panel34.PerformLayout();
            this.tabNhanVien.ResumeLayout(false);
            this.tabQLNhanVien.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel25.ResumeLayout(false);
            this.panel26.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.panel28.ResumeLayout(false);
            this.panel29.ResumeLayout(false);
            this.panel30.ResumeLayout(false);
            this.panel35.ResumeLayout(false);
            this.panel44.ResumeLayout(false);
            this.panel44.PerformLayout();
            this.panel43.ResumeLayout(false);
            this.panel43.PerformLayout();
            this.panel42.ResumeLayout(false);
            this.panel42.PerformLayout();
            this.panel41.ResumeLayout(false);
            this.panel41.PerformLayout();
            this.panel40.ResumeLayout(false);
            this.panel40.PerformLayout();
            this.panel36.ResumeLayout(false);
            this.panel36.PerformLayout();
            this.panel37.ResumeLayout(false);
            this.panel37.PerformLayout();
            this.panel38.ResumeLayout(false);
            this.panel39.ResumeLayout(false);
            this.panel39.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numGiaBan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numNamXB)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numSoLuong)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabPage tabQLQuyen;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.ListView lsvQuyen;
        private System.Windows.Forms.ColumnHeader clm_MaNV;
        private System.Windows.Forms.ColumnHeader clm_TenNV;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Button btn_SuaQuyen;
        private System.Windows.Forms.Button btn_LMNV;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.TextBox txt_TenNV;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.TextBox txt_MaNV;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.TextBox txt_TimNV;
        private System.Windows.Forms.Button btn_TimNV;
        private System.Windows.Forms.TabControl tabNhanVien;
        private System.Windows.Forms.TabPage tabQLNhanVien;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.ListView lsvNhanVien;
        private System.Windows.Forms.ColumnHeader clmMaNV;
        private System.Windows.Forms.ColumnHeader clmTenDangNhap;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Button btnThemNV;
        private System.Windows.Forms.Button btnSuaNV;
        private System.Windows.Forms.Button btnXoaNV;
        private System.Windows.Forms.Button btnLMNV;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.TextBox txtTenDangNhap;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.TextBox txtMaNV;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.TextBox txtTimNV;
        private System.Windows.Forms.Button btnTimNV;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnTimSach;
        private System.Windows.Forms.TextBox txtTimSach;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMaSach;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtTenSach;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.NumericUpDown numGiaBan;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.NumericUpDown numNamXB;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.NumericUpDown numSoLuong;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.ComboBox cmbNXB;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox cmbTL;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox cmbTG;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnLMSach;
        private System.Windows.Forms.Button btnXoaSach;
        private System.Windows.Forms.Button btnSuaSach;
        private System.Windows.Forms.Button btnThemSach;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.ColumnHeader clmHoTen;
        private System.Windows.Forms.ColumnHeader clmGioiTinh;
        private System.Windows.Forms.ColumnHeader clmNgaySinh;
        private System.Windows.Forms.ColumnHeader clmSDT;
        private System.Windows.Forms.ColumnHeader clmDiaChi;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.RadioButton radNu;
        private System.Windows.Forms.RadioButton radNam;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.TextBox txtHoTen;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.TextBox txtSDT;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.DateTimePicker dtpNgaySinh;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Button btnDatLaiMK;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.ColumnHeader clm_Quyen;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.ComboBox cmb_Quyen;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.ImageList imgList;
        private System.Windows.Forms.ColumnHeader clm_TenDangNhap;
    }
}