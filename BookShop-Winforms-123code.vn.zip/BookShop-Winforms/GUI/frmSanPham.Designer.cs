﻿namespace GUI
{
    partial class frmSanPham
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSanPham));
            this.tabSanPham = new System.Windows.Forms.TabControl();
            this.tabSach = new System.Windows.Forms.TabPage();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.lsvSach = new System.Windows.Forms.ListView();
            this.clmMaSach = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmTenSach = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmGiaBan = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmNamXB = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmSoLuongTon = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmNXB = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmTheLoai = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmTacGia = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel4 = new System.Windows.Forms.Panel();
            this.btnXuatSach = new System.Windows.Forms.Button();
            this.imgList = new System.Windows.Forms.ImageList(this.components);
            this.btnThemSach = new System.Windows.Forms.Button();
            this.btnSuaSach = new System.Windows.Forms.Button();
            this.btnXoaSach = new System.Windows.Forms.Button();
            this.btnLMSach = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel7 = new System.Windows.Forms.Panel();
            this.panel9 = new System.Windows.Forms.Panel();
            this.panel17 = new System.Windows.Forms.Panel();
            this.cmbTG = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.panel16 = new System.Windows.Forms.Panel();
            this.cmbTL = new System.Windows.Forms.ComboBox();
            this.label8 = new System.Windows.Forms.Label();
            this.panel15 = new System.Windows.Forms.Panel();
            this.label7 = new System.Windows.Forms.Label();
            this.cmbNXB = new System.Windows.Forms.ComboBox();
            this.panel14 = new System.Windows.Forms.Panel();
            this.numSoLuong = new System.Windows.Forms.NumericUpDown();
            this.label6 = new System.Windows.Forms.Label();
            this.panel13 = new System.Windows.Forms.Panel();
            this.numNamXB = new System.Windows.Forms.NumericUpDown();
            this.label5 = new System.Windows.Forms.Label();
            this.panel12 = new System.Windows.Forms.Panel();
            this.numGiaBan = new System.Windows.Forms.NumericUpDown();
            this.label4 = new System.Windows.Forms.Label();
            this.panel11 = new System.Windows.Forms.Panel();
            this.txtTenSach = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.panel10 = new System.Windows.Forms.Panel();
            this.txtMaSach = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.panel8 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel5 = new System.Windows.Forms.Panel();
            this.txtTimSach = new System.Windows.Forms.TextBox();
            this.btnTimSach = new System.Windows.Forms.Button();
            this.tabNXB = new System.Windows.Forms.TabPage();
            this.panel18 = new System.Windows.Forms.Panel();
            this.panel19 = new System.Windows.Forms.Panel();
            this.panel20 = new System.Windows.Forms.Panel();
            this.lsvNXB = new System.Windows.Forms.ListView();
            this.clmMaNXB = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmTenNXB = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmDiaChi = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel21 = new System.Windows.Forms.Panel();
            this.btnThemNXB = new System.Windows.Forms.Button();
            this.btnSuaNXB = new System.Windows.Forms.Button();
            this.btnXoaNXB = new System.Windows.Forms.Button();
            this.btnLMNXB = new System.Windows.Forms.Button();
            this.panel22 = new System.Windows.Forms.Panel();
            this.panel23 = new System.Windows.Forms.Panel();
            this.panel24 = new System.Windows.Forms.Panel();
            this.panel53 = new System.Windows.Forms.Panel();
            this.txtDiaChi = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.panel31 = new System.Windows.Forms.Panel();
            this.txtTenNXB = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.panel32 = new System.Windows.Forms.Panel();
            this.txtMaNXB = new System.Windows.Forms.TextBox();
            this.label17 = new System.Windows.Forms.Label();
            this.panel33 = new System.Windows.Forms.Panel();
            this.label18 = new System.Windows.Forms.Label();
            this.panel34 = new System.Windows.Forms.Panel();
            this.txtTimNXB = new System.Windows.Forms.TextBox();
            this.btnTimNXB = new System.Windows.Forms.Button();
            this.tabTheLoai = new System.Windows.Forms.TabPage();
            this.panel25 = new System.Windows.Forms.Panel();
            this.panel26 = new System.Windows.Forms.Panel();
            this.panel27 = new System.Windows.Forms.Panel();
            this.lsvTheLoai = new System.Windows.Forms.ListView();
            this.clmMaTL = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmTenTL = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel28 = new System.Windows.Forms.Panel();
            this.btnThemTL = new System.Windows.Forms.Button();
            this.btnSuaTL = new System.Windows.Forms.Button();
            this.btnXoaTL = new System.Windows.Forms.Button();
            this.btnLMTL = new System.Windows.Forms.Button();
            this.panel29 = new System.Windows.Forms.Panel();
            this.panel30 = new System.Windows.Forms.Panel();
            this.panel35 = new System.Windows.Forms.Panel();
            this.panel36 = new System.Windows.Forms.Panel();
            this.txtTenTL = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.panel37 = new System.Windows.Forms.Panel();
            this.txtMaTL = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.panel38 = new System.Windows.Forms.Panel();
            this.label12 = new System.Windows.Forms.Label();
            this.panel39 = new System.Windows.Forms.Panel();
            this.txtTimTL = new System.Windows.Forms.TextBox();
            this.btnTimTL = new System.Windows.Forms.Button();
            this.tabTacGia = new System.Windows.Forms.TabPage();
            this.panel40 = new System.Windows.Forms.Panel();
            this.panel41 = new System.Windows.Forms.Panel();
            this.panel42 = new System.Windows.Forms.Panel();
            this.lsvTacGia = new System.Windows.Forms.ListView();
            this.clmMaTG = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmTenTG = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmSDT = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.clmDiaChi_TG = ((System.Windows.Forms.ColumnHeader)(new System.Windows.Forms.ColumnHeader()));
            this.panel43 = new System.Windows.Forms.Panel();
            this.btnThemTG = new System.Windows.Forms.Button();
            this.btnSuaTG = new System.Windows.Forms.Button();
            this.btnXoaTG = new System.Windows.Forms.Button();
            this.btnLMTG = new System.Windows.Forms.Button();
            this.panel44 = new System.Windows.Forms.Panel();
            this.panel45 = new System.Windows.Forms.Panel();
            this.panel46 = new System.Windows.Forms.Panel();
            this.panel52 = new System.Windows.Forms.Panel();
            this.txtDiaChiTG = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.panel51 = new System.Windows.Forms.Panel();
            this.txtSDT = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.panel47 = new System.Windows.Forms.Panel();
            this.txtTenTG = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.panel48 = new System.Windows.Forms.Panel();
            this.txtMaTG = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.panel49 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.panel50 = new System.Windows.Forms.Panel();
            this.txtTimTG = new System.Windows.Forms.TextBox();
            this.btnTimTG = new System.Windows.Forms.Button();
            this.tabSanPham.SuspendLayout();
            this.tabSach.SuspendLayout();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel6.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel7.SuspendLayout();
            this.panel9.SuspendLayout();
            this.panel17.SuspendLayout();
            this.panel16.SuspendLayout();
            this.panel15.SuspendLayout();
            this.panel14.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSoLuong)).BeginInit();
            this.panel13.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numNamXB)).BeginInit();
            this.panel12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numGiaBan)).BeginInit();
            this.panel11.SuspendLayout();
            this.panel10.SuspendLayout();
            this.panel8.SuspendLayout();
            this.panel5.SuspendLayout();
            this.tabNXB.SuspendLayout();
            this.panel18.SuspendLayout();
            this.panel19.SuspendLayout();
            this.panel20.SuspendLayout();
            this.panel21.SuspendLayout();
            this.panel22.SuspendLayout();
            this.panel23.SuspendLayout();
            this.panel24.SuspendLayout();
            this.panel53.SuspendLayout();
            this.panel31.SuspendLayout();
            this.panel32.SuspendLayout();
            this.panel33.SuspendLayout();
            this.panel34.SuspendLayout();
            this.tabTheLoai.SuspendLayout();
            this.panel25.SuspendLayout();
            this.panel26.SuspendLayout();
            this.panel27.SuspendLayout();
            this.panel28.SuspendLayout();
            this.panel29.SuspendLayout();
            this.panel30.SuspendLayout();
            this.panel35.SuspendLayout();
            this.panel36.SuspendLayout();
            this.panel37.SuspendLayout();
            this.panel38.SuspendLayout();
            this.panel39.SuspendLayout();
            this.tabTacGia.SuspendLayout();
            this.panel40.SuspendLayout();
            this.panel41.SuspendLayout();
            this.panel42.SuspendLayout();
            this.panel43.SuspendLayout();
            this.panel44.SuspendLayout();
            this.panel45.SuspendLayout();
            this.panel46.SuspendLayout();
            this.panel52.SuspendLayout();
            this.panel51.SuspendLayout();
            this.panel47.SuspendLayout();
            this.panel48.SuspendLayout();
            this.panel49.SuspendLayout();
            this.panel50.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabSanPham
            // 
            this.tabSanPham.Controls.Add(this.tabSach);
            this.tabSanPham.Controls.Add(this.tabNXB);
            this.tabSanPham.Controls.Add(this.tabTheLoai);
            this.tabSanPham.Controls.Add(this.tabTacGia);
            this.tabSanPham.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabSanPham.ImageList = this.imgList;
            this.tabSanPham.Location = new System.Drawing.Point(0, 0);
            this.tabSanPham.Name = "tabSanPham";
            this.tabSanPham.SelectedIndex = 0;
            this.tabSanPham.Size = new System.Drawing.Size(1182, 673);
            this.tabSanPham.TabIndex = 0;
            // 
            // tabSach
            // 
            this.tabSach.Controls.Add(this.panel1);
            this.tabSach.ImageIndex = 5;
            this.tabSach.Location = new System.Drawing.Point(4, 31);
            this.tabSach.Name = "tabSach";
            this.tabSach.Padding = new System.Windows.Forms.Padding(3);
            this.tabSach.Size = new System.Drawing.Size(1174, 638);
            this.tabSach.TabIndex = 0;
            this.tabSach.Text = "Sách";
            this.tabSach.UseVisualStyleBackColor = true;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(3, 3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1168, 632);
            this.panel1.TabIndex = 0;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.panel6);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(740, 632);
            this.panel2.TabIndex = 0;
            // 
            // panel6
            // 
            this.panel6.Controls.Add(this.lsvSach);
            this.panel6.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel6.Location = new System.Drawing.Point(0, 49);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(740, 583);
            this.panel6.TabIndex = 1;
            // 
            // lsvSach
            // 
            this.lsvSach.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clmMaSach,
            this.clmTenSach,
            this.clmGiaBan,
            this.clmNamXB,
            this.clmSoLuongTon,
            this.clmNXB,
            this.clmTheLoai,
            this.clmTacGia});
            this.lsvSach.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lsvSach.FullRowSelect = true;
            this.lsvSach.GridLines = true;
            this.lsvSach.HideSelection = false;
            this.lsvSach.Location = new System.Drawing.Point(0, 0);
            this.lsvSach.MultiSelect = false;
            this.lsvSach.Name = "lsvSach";
            this.lsvSach.Size = new System.Drawing.Size(740, 583);
            this.lsvSach.TabIndex = 0;
            this.lsvSach.TabStop = false;
            this.lsvSach.UseCompatibleStateImageBehavior = false;
            this.lsvSach.View = System.Windows.Forms.View.Details;
            this.lsvSach.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.lsvSach_ColumnClick);
            this.lsvSach.SelectedIndexChanged += new System.EventHandler(this.lsvSach_SelectedIndexChanged);
            // 
            // clmMaSach
            // 
            this.clmMaSach.Text = "Mã Sách";
            this.clmMaSach.Width = 94;
            // 
            // clmTenSach
            // 
            this.clmTenSach.Text = "Tên Sách";
            this.clmTenSach.Width = 350;
            // 
            // clmGiaBan
            // 
            this.clmGiaBan.Text = "Giá Bán";
            this.clmGiaBan.Width = 120;
            // 
            // clmNamXB
            // 
            this.clmNamXB.Text = "Năm XB";
            this.clmNamXB.Width = 100;
            // 
            // clmSoLuongTon
            // 
            this.clmSoLuongTon.Text = "Số Lượng Tồn";
            this.clmSoLuongTon.Width = 100;
            // 
            // clmNXB
            // 
            this.clmNXB.Text = "Nhà Xuất Bản";
            this.clmNXB.Width = 220;
            // 
            // clmTheLoai
            // 
            this.clmTheLoai.Text = "Thể Loại";
            this.clmTheLoai.Width = 120;
            // 
            // clmTacGia
            // 
            this.clmTacGia.Text = "Tác Giả";
            this.clmTacGia.Width = 220;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.btnXuatSach);
            this.panel4.Controls.Add(this.btnThemSach);
            this.panel4.Controls.Add(this.btnSuaSach);
            this.panel4.Controls.Add(this.btnXoaSach);
            this.panel4.Controls.Add(this.btnLMSach);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(740, 49);
            this.panel4.TabIndex = 0;
            // 
            // btnXuatSach
            // 
            this.btnXuatSach.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnXuatSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnXuatSach.FlatAppearance.BorderSize = 0;
            this.btnXuatSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXuatSach.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXuatSach.ForeColor = System.Drawing.Color.White;
            this.btnXuatSach.ImageIndex = 9;
            this.btnXuatSach.ImageList = this.imgList;
            this.btnXuatSach.Location = new System.Drawing.Point(145, 3);
            this.btnXuatSach.Name = "btnXuatSach";
            this.btnXuatSach.Size = new System.Drawing.Size(113, 40);
            this.btnXuatSach.TabIndex = 4;
            this.btnXuatSach.Text = "Excel";
            this.btnXuatSach.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnXuatSach.UseVisualStyleBackColor = false;
            this.btnXuatSach.Click += new System.EventHandler(this.btnXuatSach_Click);
            // 
            // imgList
            // 
            this.imgList.ImageStream = ((System.Windows.Forms.ImageListStreamer)(resources.GetObject("imgList.ImageStream")));
            this.imgList.TransparentColor = System.Drawing.Color.Transparent;
            this.imgList.Images.SetKeyName(0, "add.png");
            this.imgList.Images.SetKeyName(1, "edit.png");
            this.imgList.Images.SetKeyName(2, "bin.png");
            this.imgList.Images.SetKeyName(3, "search.png");
            this.imgList.Images.SetKeyName(4, "clear.png");
            this.imgList.Images.SetKeyName(5, "book.png");
            this.imgList.Images.SetKeyName(6, "publisher.png");
            this.imgList.Images.SetKeyName(7, "category.png");
            this.imgList.Images.SetKeyName(8, "author.png");
            this.imgList.Images.SetKeyName(9, "excel.png");
            // 
            // btnThemSach
            // 
            this.btnThemSach.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThemSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnThemSach.FlatAppearance.BorderSize = 0;
            this.btnThemSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemSach.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemSach.ForeColor = System.Drawing.Color.White;
            this.btnThemSach.ImageIndex = 0;
            this.btnThemSach.ImageList = this.imgList;
            this.btnThemSach.Location = new System.Drawing.Point(264, 3);
            this.btnThemSach.Name = "btnThemSach";
            this.btnThemSach.Size = new System.Drawing.Size(113, 40);
            this.btnThemSach.TabIndex = 0;
            this.btnThemSach.Text = "Thêm";
            this.btnThemSach.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnThemSach.UseVisualStyleBackColor = false;
            this.btnThemSach.Click += new System.EventHandler(this.btnThemSach_Click);
            // 
            // btnSuaSach
            // 
            this.btnSuaSach.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSuaSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnSuaSach.FlatAppearance.BorderSize = 0;
            this.btnSuaSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSuaSach.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuaSach.ForeColor = System.Drawing.Color.White;
            this.btnSuaSach.ImageIndex = 1;
            this.btnSuaSach.ImageList = this.imgList;
            this.btnSuaSach.Location = new System.Drawing.Point(383, 3);
            this.btnSuaSach.Name = "btnSuaSach";
            this.btnSuaSach.Size = new System.Drawing.Size(113, 40);
            this.btnSuaSach.TabIndex = 1;
            this.btnSuaSach.Text = "Sửa";
            this.btnSuaSach.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSuaSach.UseVisualStyleBackColor = false;
            this.btnSuaSach.Click += new System.EventHandler(this.btnSuaSach_Click);
            // 
            // btnXoaSach
            // 
            this.btnXoaSach.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnXoaSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnXoaSach.FlatAppearance.BorderSize = 0;
            this.btnXoaSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoaSach.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaSach.ForeColor = System.Drawing.Color.White;
            this.btnXoaSach.ImageIndex = 2;
            this.btnXoaSach.ImageList = this.imgList;
            this.btnXoaSach.Location = new System.Drawing.Point(502, 3);
            this.btnXoaSach.Name = "btnXoaSach";
            this.btnXoaSach.Size = new System.Drawing.Size(113, 40);
            this.btnXoaSach.TabIndex = 2;
            this.btnXoaSach.Text = "Xóa";
            this.btnXoaSach.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnXoaSach.UseVisualStyleBackColor = false;
            this.btnXoaSach.Click += new System.EventHandler(this.btnXoaSach_Click);
            // 
            // btnLMSach
            // 
            this.btnLMSach.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLMSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnLMSach.FlatAppearance.BorderSize = 0;
            this.btnLMSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLMSach.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLMSach.ForeColor = System.Drawing.Color.White;
            this.btnLMSach.ImageIndex = 4;
            this.btnLMSach.ImageList = this.imgList;
            this.btnLMSach.Location = new System.Drawing.Point(621, 3);
            this.btnLMSach.Name = "btnLMSach";
            this.btnLMSach.Size = new System.Drawing.Size(113, 40);
            this.btnLMSach.TabIndex = 3;
            this.btnLMSach.Text = "Làm mới";
            this.btnLMSach.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnLMSach.UseVisualStyleBackColor = false;
            this.btnLMSach.Click += new System.EventHandler(this.btnLMSach_Click);
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.panel7);
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel3.Location = new System.Drawing.Point(740, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(428, 632);
            this.panel3.TabIndex = 1;
            // 
            // panel7
            // 
            this.panel7.Controls.Add(this.panel9);
            this.panel7.Controls.Add(this.panel8);
            this.panel7.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel7.Location = new System.Drawing.Point(0, 49);
            this.panel7.Name = "panel7";
            this.panel7.Size = new System.Drawing.Size(428, 583);
            this.panel7.TabIndex = 1;
            // 
            // panel9
            // 
            this.panel9.Controls.Add(this.panel17);
            this.panel9.Controls.Add(this.panel16);
            this.panel9.Controls.Add(this.panel15);
            this.panel9.Controls.Add(this.panel14);
            this.panel9.Controls.Add(this.panel13);
            this.panel9.Controls.Add(this.panel12);
            this.panel9.Controls.Add(this.panel11);
            this.panel9.Controls.Add(this.panel10);
            this.panel9.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel9.Location = new System.Drawing.Point(0, 45);
            this.panel9.Name = "panel9";
            this.panel9.Size = new System.Drawing.Size(428, 538);
            this.panel9.TabIndex = 0;
            // 
            // panel17
            // 
            this.panel17.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel17.Controls.Add(this.cmbTG);
            this.panel17.Controls.Add(this.label9);
            this.panel17.Location = new System.Drawing.Point(6, 392);
            this.panel17.Name = "panel17";
            this.panel17.Size = new System.Drawing.Size(416, 38);
            this.panel17.TabIndex = 7;
            // 
            // cmbTG
            // 
            this.cmbTG.Enabled = false;
            this.cmbTG.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTG.FormattingEnabled = true;
            this.cmbTG.Location = new System.Drawing.Point(117, 3);
            this.cmbTG.Name = "cmbTG";
            this.cmbTG.Size = new System.Drawing.Size(296, 33);
            this.cmbTG.TabIndex = 1;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(4, 7);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(80, 24);
            this.label9.TabIndex = 0;
            this.label9.Text = "Tác Giả:";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel16
            // 
            this.panel16.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel16.Controls.Add(this.cmbTL);
            this.panel16.Controls.Add(this.label8);
            this.panel16.Location = new System.Drawing.Point(6, 337);
            this.panel16.Name = "panel16";
            this.panel16.Size = new System.Drawing.Size(416, 38);
            this.panel16.TabIndex = 6;
            // 
            // cmbTL
            // 
            this.cmbTL.Enabled = false;
            this.cmbTL.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbTL.FormattingEnabled = true;
            this.cmbTL.Location = new System.Drawing.Point(117, 2);
            this.cmbTL.Name = "cmbTL";
            this.cmbTL.Size = new System.Drawing.Size(296, 33);
            this.cmbTL.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(4, 7);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(89, 24);
            this.label8.TabIndex = 0;
            this.label8.Text = "Thể Loại:";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel15
            // 
            this.panel15.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel15.Controls.Add(this.label7);
            this.panel15.Controls.Add(this.cmbNXB);
            this.panel15.Location = new System.Drawing.Point(6, 282);
            this.panel15.Name = "panel15";
            this.panel15.Size = new System.Drawing.Size(416, 38);
            this.panel15.TabIndex = 5;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(4, 7);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(81, 24);
            this.label7.TabIndex = 0;
            this.label7.Text = "Nhà XB:";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cmbNXB
            // 
            this.cmbNXB.Enabled = false;
            this.cmbNXB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbNXB.FormattingEnabled = true;
            this.cmbNXB.Location = new System.Drawing.Point(117, 3);
            this.cmbNXB.Name = "cmbNXB";
            this.cmbNXB.Size = new System.Drawing.Size(296, 33);
            this.cmbNXB.TabIndex = 1;
            // 
            // panel14
            // 
            this.panel14.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel14.Controls.Add(this.numSoLuong);
            this.panel14.Controls.Add(this.label6);
            this.panel14.Location = new System.Drawing.Point(6, 227);
            this.panel14.Name = "panel14";
            this.panel14.Size = new System.Drawing.Size(416, 38);
            this.panel14.TabIndex = 4;
            // 
            // numSoLuong
            // 
            this.numSoLuong.Enabled = false;
            this.numSoLuong.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numSoLuong.Location = new System.Drawing.Point(117, 3);
            this.numSoLuong.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.numSoLuong.Name = "numSoLuong";
            this.numSoLuong.Size = new System.Drawing.Size(155, 30);
            this.numSoLuong.TabIndex = 4;
            this.numSoLuong.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numSoLuong.ThousandsSeparator = true;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(4, 7);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(97, 24);
            this.label6.TabIndex = 0;
            this.label6.Text = "Số Lượng:";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel13
            // 
            this.panel13.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel13.Controls.Add(this.numNamXB);
            this.panel13.Controls.Add(this.label5);
            this.panel13.Location = new System.Drawing.Point(6, 172);
            this.panel13.Name = "panel13";
            this.panel13.Size = new System.Drawing.Size(416, 38);
            this.panel13.TabIndex = 3;
            // 
            // numNamXB
            // 
            this.numNamXB.Enabled = false;
            this.numNamXB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numNamXB.Location = new System.Drawing.Point(117, 3);
            this.numNamXB.Maximum = new decimal(new int[] {
            2018,
            0,
            0,
            0});
            this.numNamXB.Minimum = new decimal(new int[] {
            1900,
            0,
            0,
            0});
            this.numNamXB.Name = "numNamXB";
            this.numNamXB.Size = new System.Drawing.Size(155, 30);
            this.numNamXB.TabIndex = 3;
            this.numNamXB.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numNamXB.Value = new decimal(new int[] {
            2018,
            0,
            0,
            0});
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(4, 7);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(86, 24);
            this.label5.TabIndex = 0;
            this.label5.Text = "Năm XB:";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel12
            // 
            this.panel12.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel12.Controls.Add(this.numGiaBan);
            this.panel12.Controls.Add(this.label4);
            this.panel12.Location = new System.Drawing.Point(6, 117);
            this.panel12.Name = "panel12";
            this.panel12.Size = new System.Drawing.Size(416, 38);
            this.panel12.TabIndex = 2;
            // 
            // numGiaBan
            // 
            this.numGiaBan.Enabled = false;
            this.numGiaBan.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.numGiaBan.Location = new System.Drawing.Point(117, 4);
            this.numGiaBan.Maximum = new decimal(new int[] {
            100000000,
            0,
            0,
            0});
            this.numGiaBan.Name = "numGiaBan";
            this.numGiaBan.Size = new System.Drawing.Size(155, 30);
            this.numGiaBan.TabIndex = 2;
            this.numGiaBan.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.numGiaBan.ThousandsSeparator = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(4, 7);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(81, 24);
            this.label4.TabIndex = 0;
            this.label4.Text = "Giá Bán:";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel11
            // 
            this.panel11.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel11.Controls.Add(this.txtTenSach);
            this.panel11.Controls.Add(this.label3);
            this.panel11.Location = new System.Drawing.Point(6, 62);
            this.panel11.Name = "panel11";
            this.panel11.Size = new System.Drawing.Size(416, 38);
            this.panel11.TabIndex = 1;
            // 
            // txtTenSach
            // 
            this.txtTenSach.Enabled = false;
            this.txtTenSach.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenSach.Location = new System.Drawing.Point(117, 3);
            this.txtTenSach.Name = "txtTenSach";
            this.txtTenSach.Size = new System.Drawing.Size(296, 30);
            this.txtTenSach.TabIndex = 1;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 7);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(97, 24);
            this.label3.TabIndex = 0;
            this.label3.Text = "Tên Sách:";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel10
            // 
            this.panel10.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel10.Controls.Add(this.txtMaSach);
            this.panel10.Controls.Add(this.label2);
            this.panel10.Location = new System.Drawing.Point(6, 7);
            this.panel10.Name = "panel10";
            this.panel10.Size = new System.Drawing.Size(416, 38);
            this.panel10.TabIndex = 0;
            // 
            // txtMaSach
            // 
            this.txtMaSach.Enabled = false;
            this.txtMaSach.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaSach.Location = new System.Drawing.Point(117, 3);
            this.txtMaSach.Name = "txtMaSach";
            this.txtMaSach.Size = new System.Drawing.Size(296, 30);
            this.txtMaSach.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(4, 7);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(89, 24);
            this.label2.TabIndex = 0;
            this.label2.Text = "Mã Sách:";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel8
            // 
            this.panel8.Controls.Add(this.label1);
            this.panel8.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel8.Location = new System.Drawing.Point(0, 0);
            this.panel8.Name = "panel8";
            this.panel8.Size = new System.Drawing.Size(428, 45);
            this.panel8.TabIndex = 0;
            // 
            // label1
            // 
            this.label1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(428, 45);
            this.label1.TabIndex = 0;
            this.label1.Text = "Thông tin chi tiết";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.txtTimSach);
            this.panel5.Controls.Add(this.btnTimSach);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel5.Location = new System.Drawing.Point(0, 0);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(428, 49);
            this.panel5.TabIndex = 0;
            // 
            // txtTimSach
            // 
            this.txtTimSach.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTimSach.Location = new System.Drawing.Point(14, 13);
            this.txtTimSach.Name = "txtTimSach";
            this.txtTimSach.Size = new System.Drawing.Size(292, 30);
            this.txtTimSach.TabIndex = 0;
            this.txtTimSach.TextChanged += new System.EventHandler(this.txtTimSach_TextChanged);
            // 
            // btnTimSach
            // 
            this.btnTimSach.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTimSach.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnTimSach.FlatAppearance.BorderSize = 0;
            this.btnTimSach.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTimSach.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimSach.ForeColor = System.Drawing.Color.White;
            this.btnTimSach.ImageIndex = 3;
            this.btnTimSach.ImageList = this.imgList;
            this.btnTimSach.Location = new System.Drawing.Point(312, 3);
            this.btnTimSach.Name = "btnTimSach";
            this.btnTimSach.Size = new System.Drawing.Size(113, 40);
            this.btnTimSach.TabIndex = 1;
            this.btnTimSach.Text = "Tìm";
            this.btnTimSach.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnTimSach.UseVisualStyleBackColor = false;
            this.btnTimSach.Click += new System.EventHandler(this.btnTimSach_Click);
            // 
            // tabNXB
            // 
            this.tabNXB.Controls.Add(this.panel18);
            this.tabNXB.ImageIndex = 6;
            this.tabNXB.Location = new System.Drawing.Point(4, 31);
            this.tabNXB.Name = "tabNXB";
            this.tabNXB.Padding = new System.Windows.Forms.Padding(3);
            this.tabNXB.Size = new System.Drawing.Size(1174, 638);
            this.tabNXB.TabIndex = 1;
            this.tabNXB.Text = "Nhà Xuất Bản";
            this.tabNXB.UseVisualStyleBackColor = true;
            // 
            // panel18
            // 
            this.panel18.Controls.Add(this.panel19);
            this.panel18.Controls.Add(this.panel22);
            this.panel18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel18.Location = new System.Drawing.Point(3, 3);
            this.panel18.Name = "panel18";
            this.panel18.Size = new System.Drawing.Size(1168, 632);
            this.panel18.TabIndex = 1;
            // 
            // panel19
            // 
            this.panel19.Controls.Add(this.panel20);
            this.panel19.Controls.Add(this.panel21);
            this.panel19.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel19.Location = new System.Drawing.Point(0, 0);
            this.panel19.Name = "panel19";
            this.panel19.Size = new System.Drawing.Size(740, 632);
            this.panel19.TabIndex = 0;
            // 
            // panel20
            // 
            this.panel20.Controls.Add(this.lsvNXB);
            this.panel20.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel20.Location = new System.Drawing.Point(0, 49);
            this.panel20.Name = "panel20";
            this.panel20.Size = new System.Drawing.Size(740, 583);
            this.panel20.TabIndex = 1;
            // 
            // lsvNXB
            // 
            this.lsvNXB.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clmMaNXB,
            this.clmTenNXB,
            this.clmDiaChi});
            this.lsvNXB.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lsvNXB.FullRowSelect = true;
            this.lsvNXB.GridLines = true;
            this.lsvNXB.HideSelection = false;
            this.lsvNXB.Location = new System.Drawing.Point(0, 0);
            this.lsvNXB.MultiSelect = false;
            this.lsvNXB.Name = "lsvNXB";
            this.lsvNXB.Size = new System.Drawing.Size(740, 583);
            this.lsvNXB.TabIndex = 0;
            this.lsvNXB.TabStop = false;
            this.lsvNXB.UseCompatibleStateImageBehavior = false;
            this.lsvNXB.View = System.Windows.Forms.View.Details;
            this.lsvNXB.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.lsvNXB_ColumnClick);
            this.lsvNXB.SelectedIndexChanged += new System.EventHandler(this.lsvNXB_SelectedIndexChanged);
            // 
            // clmMaNXB
            // 
            this.clmMaNXB.Text = "Mã Nhà Xuất Bản";
            this.clmMaNXB.Width = 178;
            // 
            // clmTenNXB
            // 
            this.clmTenNXB.Text = "Tên Nhà Xuất Bản";
            this.clmTenNXB.Width = 350;
            // 
            // clmDiaChi
            // 
            this.clmDiaChi.Text = "Địa Chỉ";
            this.clmDiaChi.Width = 250;
            // 
            // panel21
            // 
            this.panel21.Controls.Add(this.btnThemNXB);
            this.panel21.Controls.Add(this.btnSuaNXB);
            this.panel21.Controls.Add(this.btnXoaNXB);
            this.panel21.Controls.Add(this.btnLMNXB);
            this.panel21.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel21.Location = new System.Drawing.Point(0, 0);
            this.panel21.Name = "panel21";
            this.panel21.Size = new System.Drawing.Size(740, 49);
            this.panel21.TabIndex = 0;
            // 
            // btnThemNXB
            // 
            this.btnThemNXB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThemNXB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnThemNXB.FlatAppearance.BorderSize = 0;
            this.btnThemNXB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemNXB.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemNXB.ForeColor = System.Drawing.Color.White;
            this.btnThemNXB.ImageIndex = 0;
            this.btnThemNXB.ImageList = this.imgList;
            this.btnThemNXB.Location = new System.Drawing.Point(264, 3);
            this.btnThemNXB.Name = "btnThemNXB";
            this.btnThemNXB.Size = new System.Drawing.Size(113, 40);
            this.btnThemNXB.TabIndex = 0;
            this.btnThemNXB.Text = "Thêm";
            this.btnThemNXB.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnThemNXB.UseVisualStyleBackColor = false;
            this.btnThemNXB.Click += new System.EventHandler(this.btnThemNXB_Click);
            // 
            // btnSuaNXB
            // 
            this.btnSuaNXB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSuaNXB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnSuaNXB.FlatAppearance.BorderSize = 0;
            this.btnSuaNXB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSuaNXB.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuaNXB.ForeColor = System.Drawing.Color.White;
            this.btnSuaNXB.ImageIndex = 1;
            this.btnSuaNXB.ImageList = this.imgList;
            this.btnSuaNXB.Location = new System.Drawing.Point(383, 3);
            this.btnSuaNXB.Name = "btnSuaNXB";
            this.btnSuaNXB.Size = new System.Drawing.Size(113, 40);
            this.btnSuaNXB.TabIndex = 1;
            this.btnSuaNXB.Text = "Sửa";
            this.btnSuaNXB.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSuaNXB.UseVisualStyleBackColor = false;
            this.btnSuaNXB.Click += new System.EventHandler(this.btnSuaNXB_Click);
            // 
            // btnXoaNXB
            // 
            this.btnXoaNXB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnXoaNXB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnXoaNXB.FlatAppearance.BorderSize = 0;
            this.btnXoaNXB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoaNXB.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaNXB.ForeColor = System.Drawing.Color.White;
            this.btnXoaNXB.ImageIndex = 2;
            this.btnXoaNXB.ImageList = this.imgList;
            this.btnXoaNXB.Location = new System.Drawing.Point(502, 3);
            this.btnXoaNXB.Name = "btnXoaNXB";
            this.btnXoaNXB.Size = new System.Drawing.Size(113, 40);
            this.btnXoaNXB.TabIndex = 2;
            this.btnXoaNXB.Text = "Xóa";
            this.btnXoaNXB.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnXoaNXB.UseVisualStyleBackColor = false;
            this.btnXoaNXB.Click += new System.EventHandler(this.btnXoaNXB_Click);
            // 
            // btnLMNXB
            // 
            this.btnLMNXB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLMNXB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnLMNXB.FlatAppearance.BorderSize = 0;
            this.btnLMNXB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLMNXB.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLMNXB.ForeColor = System.Drawing.Color.White;
            this.btnLMNXB.ImageIndex = 4;
            this.btnLMNXB.ImageList = this.imgList;
            this.btnLMNXB.Location = new System.Drawing.Point(621, 3);
            this.btnLMNXB.Name = "btnLMNXB";
            this.btnLMNXB.Size = new System.Drawing.Size(113, 40);
            this.btnLMNXB.TabIndex = 3;
            this.btnLMNXB.Text = "Làm mới";
            this.btnLMNXB.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnLMNXB.UseVisualStyleBackColor = false;
            this.btnLMNXB.Click += new System.EventHandler(this.btnLMNXB_Click);
            // 
            // panel22
            // 
            this.panel22.Controls.Add(this.panel23);
            this.panel22.Controls.Add(this.panel34);
            this.panel22.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel22.Location = new System.Drawing.Point(740, 0);
            this.panel22.Name = "panel22";
            this.panel22.Size = new System.Drawing.Size(428, 632);
            this.panel22.TabIndex = 1;
            // 
            // panel23
            // 
            this.panel23.Controls.Add(this.panel24);
            this.panel23.Controls.Add(this.panel33);
            this.panel23.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel23.Location = new System.Drawing.Point(0, 49);
            this.panel23.Name = "panel23";
            this.panel23.Size = new System.Drawing.Size(428, 583);
            this.panel23.TabIndex = 1;
            // 
            // panel24
            // 
            this.panel24.Controls.Add(this.panel53);
            this.panel24.Controls.Add(this.panel31);
            this.panel24.Controls.Add(this.panel32);
            this.panel24.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel24.Location = new System.Drawing.Point(0, 45);
            this.panel24.Name = "panel24";
            this.panel24.Size = new System.Drawing.Size(428, 538);
            this.panel24.TabIndex = 0;
            // 
            // panel53
            // 
            this.panel53.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel53.Controls.Add(this.txtDiaChi);
            this.panel53.Controls.Add(this.label21);
            this.panel53.Location = new System.Drawing.Point(6, 115);
            this.panel53.Name = "panel53";
            this.panel53.Size = new System.Drawing.Size(416, 81);
            this.panel53.TabIndex = 2;
            // 
            // txtDiaChi
            // 
            this.txtDiaChi.Enabled = false;
            this.txtDiaChi.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiaChi.Location = new System.Drawing.Point(117, 3);
            this.txtDiaChi.Multiline = true;
            this.txtDiaChi.Name = "txtDiaChi";
            this.txtDiaChi.Size = new System.Drawing.Size(296, 75);
            this.txtDiaChi.TabIndex = 1;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(4, 7);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(75, 24);
            this.label21.TabIndex = 0;
            this.label21.Text = "Địa Chỉ:";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel31
            // 
            this.panel31.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel31.Controls.Add(this.txtTenNXB);
            this.panel31.Controls.Add(this.label16);
            this.panel31.Location = new System.Drawing.Point(6, 61);
            this.panel31.Name = "panel31";
            this.panel31.Size = new System.Drawing.Size(416, 38);
            this.panel31.TabIndex = 1;
            // 
            // txtTenNXB
            // 
            this.txtTenNXB.Enabled = false;
            this.txtTenNXB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenNXB.Location = new System.Drawing.Point(117, 3);
            this.txtTenNXB.Name = "txtTenNXB";
            this.txtTenNXB.Size = new System.Drawing.Size(296, 30);
            this.txtTenNXB.TabIndex = 1;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(4, 7);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(94, 24);
            this.label16.TabIndex = 0;
            this.label16.Text = "Tên NXB:";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel32
            // 
            this.panel32.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel32.Controls.Add(this.txtMaNXB);
            this.panel32.Controls.Add(this.label17);
            this.panel32.Location = new System.Drawing.Point(6, 7);
            this.panel32.Name = "panel32";
            this.panel32.Size = new System.Drawing.Size(416, 38);
            this.panel32.TabIndex = 0;
            // 
            // txtMaNXB
            // 
            this.txtMaNXB.Enabled = false;
            this.txtMaNXB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaNXB.Location = new System.Drawing.Point(117, 3);
            this.txtMaNXB.Name = "txtMaNXB";
            this.txtMaNXB.Size = new System.Drawing.Size(296, 30);
            this.txtMaNXB.TabIndex = 1;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(4, 7);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(86, 24);
            this.label17.TabIndex = 0;
            this.label17.Text = "Mã NXB:";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel33
            // 
            this.panel33.Controls.Add(this.label18);
            this.panel33.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel33.Location = new System.Drawing.Point(0, 0);
            this.panel33.Name = "panel33";
            this.panel33.Size = new System.Drawing.Size(428, 45);
            this.panel33.TabIndex = 0;
            // 
            // label18
            // 
            this.label18.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(0, 0);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(428, 45);
            this.label18.TabIndex = 0;
            this.label18.Text = "Thông tin chi tiết";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel34
            // 
            this.panel34.Controls.Add(this.txtTimNXB);
            this.panel34.Controls.Add(this.btnTimNXB);
            this.panel34.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel34.Location = new System.Drawing.Point(0, 0);
            this.panel34.Name = "panel34";
            this.panel34.Size = new System.Drawing.Size(428, 49);
            this.panel34.TabIndex = 0;
            // 
            // txtTimNXB
            // 
            this.txtTimNXB.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTimNXB.Location = new System.Drawing.Point(14, 13);
            this.txtTimNXB.Name = "txtTimNXB";
            this.txtTimNXB.Size = new System.Drawing.Size(292, 30);
            this.txtTimNXB.TabIndex = 0;
            this.txtTimNXB.TextChanged += new System.EventHandler(this.txtTimNXB_TextChanged);
            // 
            // btnTimNXB
            // 
            this.btnTimNXB.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTimNXB.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnTimNXB.FlatAppearance.BorderSize = 0;
            this.btnTimNXB.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTimNXB.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimNXB.ForeColor = System.Drawing.Color.White;
            this.btnTimNXB.ImageIndex = 3;
            this.btnTimNXB.ImageList = this.imgList;
            this.btnTimNXB.Location = new System.Drawing.Point(312, 3);
            this.btnTimNXB.Name = "btnTimNXB";
            this.btnTimNXB.Size = new System.Drawing.Size(113, 40);
            this.btnTimNXB.TabIndex = 1;
            this.btnTimNXB.Text = "Tìm";
            this.btnTimNXB.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnTimNXB.UseVisualStyleBackColor = false;
            this.btnTimNXB.Click += new System.EventHandler(this.btnTimNXB_Click);
            // 
            // tabTheLoai
            // 
            this.tabTheLoai.Controls.Add(this.panel25);
            this.tabTheLoai.ImageIndex = 7;
            this.tabTheLoai.Location = new System.Drawing.Point(4, 31);
            this.tabTheLoai.Name = "tabTheLoai";
            this.tabTheLoai.Padding = new System.Windows.Forms.Padding(3);
            this.tabTheLoai.Size = new System.Drawing.Size(1174, 638);
            this.tabTheLoai.TabIndex = 2;
            this.tabTheLoai.Text = "Thể Loại";
            this.tabTheLoai.UseVisualStyleBackColor = true;
            // 
            // panel25
            // 
            this.panel25.Controls.Add(this.panel26);
            this.panel25.Controls.Add(this.panel29);
            this.panel25.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel25.Location = new System.Drawing.Point(3, 3);
            this.panel25.Name = "panel25";
            this.panel25.Size = new System.Drawing.Size(1168, 632);
            this.panel25.TabIndex = 2;
            // 
            // panel26
            // 
            this.panel26.Controls.Add(this.panel27);
            this.panel26.Controls.Add(this.panel28);
            this.panel26.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel26.Location = new System.Drawing.Point(0, 0);
            this.panel26.Name = "panel26";
            this.panel26.Size = new System.Drawing.Size(740, 632);
            this.panel26.TabIndex = 0;
            // 
            // panel27
            // 
            this.panel27.Controls.Add(this.lsvTheLoai);
            this.panel27.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel27.Location = new System.Drawing.Point(0, 49);
            this.panel27.Name = "panel27";
            this.panel27.Size = new System.Drawing.Size(740, 583);
            this.panel27.TabIndex = 1;
            // 
            // lsvTheLoai
            // 
            this.lsvTheLoai.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clmMaTL,
            this.clmTenTL});
            this.lsvTheLoai.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lsvTheLoai.FullRowSelect = true;
            this.lsvTheLoai.GridLines = true;
            this.lsvTheLoai.HideSelection = false;
            this.lsvTheLoai.Location = new System.Drawing.Point(0, 0);
            this.lsvTheLoai.MultiSelect = false;
            this.lsvTheLoai.Name = "lsvTheLoai";
            this.lsvTheLoai.Size = new System.Drawing.Size(740, 583);
            this.lsvTheLoai.TabIndex = 0;
            this.lsvTheLoai.TabStop = false;
            this.lsvTheLoai.UseCompatibleStateImageBehavior = false;
            this.lsvTheLoai.View = System.Windows.Forms.View.Details;
            this.lsvTheLoai.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.lsvTheLoai_ColumnClick);
            this.lsvTheLoai.SelectedIndexChanged += new System.EventHandler(this.lsvTheLoai_SelectedIndexChanged);
            // 
            // clmMaTL
            // 
            this.clmMaTL.Text = "Mã Thể Loại";
            this.clmMaTL.Width = 140;
            // 
            // clmTenTL
            // 
            this.clmTenTL.Text = "Tên Thể loại";
            this.clmTenTL.Width = 580;
            // 
            // panel28
            // 
            this.panel28.Controls.Add(this.btnThemTL);
            this.panel28.Controls.Add(this.btnSuaTL);
            this.panel28.Controls.Add(this.btnXoaTL);
            this.panel28.Controls.Add(this.btnLMTL);
            this.panel28.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel28.Location = new System.Drawing.Point(0, 0);
            this.panel28.Name = "panel28";
            this.panel28.Size = new System.Drawing.Size(740, 49);
            this.panel28.TabIndex = 0;
            // 
            // btnThemTL
            // 
            this.btnThemTL.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThemTL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnThemTL.FlatAppearance.BorderSize = 0;
            this.btnThemTL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemTL.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemTL.ForeColor = System.Drawing.Color.White;
            this.btnThemTL.ImageIndex = 0;
            this.btnThemTL.ImageList = this.imgList;
            this.btnThemTL.Location = new System.Drawing.Point(264, 3);
            this.btnThemTL.Name = "btnThemTL";
            this.btnThemTL.Size = new System.Drawing.Size(113, 40);
            this.btnThemTL.TabIndex = 0;
            this.btnThemTL.Text = "Thêm";
            this.btnThemTL.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnThemTL.UseVisualStyleBackColor = false;
            this.btnThemTL.Click += new System.EventHandler(this.btnThemTL_Click);
            // 
            // btnSuaTL
            // 
            this.btnSuaTL.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSuaTL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnSuaTL.FlatAppearance.BorderSize = 0;
            this.btnSuaTL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSuaTL.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuaTL.ForeColor = System.Drawing.Color.White;
            this.btnSuaTL.ImageIndex = 1;
            this.btnSuaTL.ImageList = this.imgList;
            this.btnSuaTL.Location = new System.Drawing.Point(383, 3);
            this.btnSuaTL.Name = "btnSuaTL";
            this.btnSuaTL.Size = new System.Drawing.Size(113, 40);
            this.btnSuaTL.TabIndex = 1;
            this.btnSuaTL.Text = "Sửa";
            this.btnSuaTL.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSuaTL.UseVisualStyleBackColor = false;
            this.btnSuaTL.Click += new System.EventHandler(this.btnSuaTL_Click);
            // 
            // btnXoaTL
            // 
            this.btnXoaTL.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnXoaTL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnXoaTL.FlatAppearance.BorderSize = 0;
            this.btnXoaTL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoaTL.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaTL.ForeColor = System.Drawing.Color.White;
            this.btnXoaTL.ImageIndex = 2;
            this.btnXoaTL.ImageList = this.imgList;
            this.btnXoaTL.Location = new System.Drawing.Point(502, 3);
            this.btnXoaTL.Name = "btnXoaTL";
            this.btnXoaTL.Size = new System.Drawing.Size(113, 40);
            this.btnXoaTL.TabIndex = 2;
            this.btnXoaTL.Text = "Xóa";
            this.btnXoaTL.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnXoaTL.UseVisualStyleBackColor = false;
            this.btnXoaTL.Click += new System.EventHandler(this.btnXoaTL_Click);
            // 
            // btnLMTL
            // 
            this.btnLMTL.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLMTL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnLMTL.FlatAppearance.BorderSize = 0;
            this.btnLMTL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLMTL.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLMTL.ForeColor = System.Drawing.Color.White;
            this.btnLMTL.ImageIndex = 4;
            this.btnLMTL.ImageList = this.imgList;
            this.btnLMTL.Location = new System.Drawing.Point(621, 3);
            this.btnLMTL.Name = "btnLMTL";
            this.btnLMTL.Size = new System.Drawing.Size(113, 40);
            this.btnLMTL.TabIndex = 3;
            this.btnLMTL.Text = "Làm mới";
            this.btnLMTL.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnLMTL.UseVisualStyleBackColor = false;
            this.btnLMTL.Click += new System.EventHandler(this.btnLMTL_Click);
            // 
            // panel29
            // 
            this.panel29.Controls.Add(this.panel30);
            this.panel29.Controls.Add(this.panel39);
            this.panel29.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel29.Location = new System.Drawing.Point(740, 0);
            this.panel29.Name = "panel29";
            this.panel29.Size = new System.Drawing.Size(428, 632);
            this.panel29.TabIndex = 1;
            // 
            // panel30
            // 
            this.panel30.Controls.Add(this.panel35);
            this.panel30.Controls.Add(this.panel38);
            this.panel30.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel30.Location = new System.Drawing.Point(0, 49);
            this.panel30.Name = "panel30";
            this.panel30.Size = new System.Drawing.Size(428, 583);
            this.panel30.TabIndex = 1;
            // 
            // panel35
            // 
            this.panel35.Controls.Add(this.panel36);
            this.panel35.Controls.Add(this.panel37);
            this.panel35.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel35.Location = new System.Drawing.Point(0, 45);
            this.panel35.Name = "panel35";
            this.panel35.Size = new System.Drawing.Size(428, 538);
            this.panel35.TabIndex = 0;
            // 
            // panel36
            // 
            this.panel36.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel36.Controls.Add(this.txtTenTL);
            this.panel36.Controls.Add(this.label10);
            this.panel36.Location = new System.Drawing.Point(6, 62);
            this.panel36.Name = "panel36";
            this.panel36.Size = new System.Drawing.Size(416, 38);
            this.panel36.TabIndex = 1;
            // 
            // txtTenTL
            // 
            this.txtTenTL.Enabled = false;
            this.txtTenTL.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenTL.Location = new System.Drawing.Point(117, 3);
            this.txtTenTL.Name = "txtTenTL";
            this.txtTenTL.Size = new System.Drawing.Size(296, 30);
            this.txtTenTL.TabIndex = 1;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(4, 7);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(76, 24);
            this.label10.TabIndex = 0;
            this.label10.Text = "Tên TL:";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel37
            // 
            this.panel37.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel37.Controls.Add(this.txtMaTL);
            this.panel37.Controls.Add(this.label11);
            this.panel37.Location = new System.Drawing.Point(6, 7);
            this.panel37.Name = "panel37";
            this.panel37.Size = new System.Drawing.Size(416, 38);
            this.panel37.TabIndex = 0;
            // 
            // txtMaTL
            // 
            this.txtMaTL.Enabled = false;
            this.txtMaTL.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaTL.Location = new System.Drawing.Point(117, 3);
            this.txtMaTL.Name = "txtMaTL";
            this.txtMaTL.Size = new System.Drawing.Size(296, 30);
            this.txtMaTL.TabIndex = 1;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(4, 7);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(68, 24);
            this.label11.TabIndex = 0;
            this.label11.Text = "Mã TL:";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel38
            // 
            this.panel38.Controls.Add(this.label12);
            this.panel38.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel38.Location = new System.Drawing.Point(0, 0);
            this.panel38.Name = "panel38";
            this.panel38.Size = new System.Drawing.Size(428, 45);
            this.panel38.TabIndex = 0;
            // 
            // label12
            // 
            this.label12.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(0, 0);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(428, 45);
            this.label12.TabIndex = 0;
            this.label12.Text = "Thông tin chi tiết";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel39
            // 
            this.panel39.Controls.Add(this.txtTimTL);
            this.panel39.Controls.Add(this.btnTimTL);
            this.panel39.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel39.Location = new System.Drawing.Point(0, 0);
            this.panel39.Name = "panel39";
            this.panel39.Size = new System.Drawing.Size(428, 49);
            this.panel39.TabIndex = 0;
            // 
            // txtTimTL
            // 
            this.txtTimTL.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTimTL.Location = new System.Drawing.Point(14, 13);
            this.txtTimTL.Name = "txtTimTL";
            this.txtTimTL.Size = new System.Drawing.Size(292, 30);
            this.txtTimTL.TabIndex = 0;
            this.txtTimTL.TextChanged += new System.EventHandler(this.txtTimTL_TextChanged);
            // 
            // btnTimTL
            // 
            this.btnTimTL.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTimTL.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnTimTL.FlatAppearance.BorderSize = 0;
            this.btnTimTL.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTimTL.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimTL.ForeColor = System.Drawing.Color.White;
            this.btnTimTL.ImageIndex = 3;
            this.btnTimTL.ImageList = this.imgList;
            this.btnTimTL.Location = new System.Drawing.Point(312, 3);
            this.btnTimTL.Name = "btnTimTL";
            this.btnTimTL.Size = new System.Drawing.Size(113, 40);
            this.btnTimTL.TabIndex = 1;
            this.btnTimTL.Text = "Tìm";
            this.btnTimTL.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnTimTL.UseVisualStyleBackColor = false;
            this.btnTimTL.Click += new System.EventHandler(this.btnTimTL_Click);
            // 
            // tabTacGia
            // 
            this.tabTacGia.Controls.Add(this.panel40);
            this.tabTacGia.ImageIndex = 8;
            this.tabTacGia.Location = new System.Drawing.Point(4, 31);
            this.tabTacGia.Name = "tabTacGia";
            this.tabTacGia.Padding = new System.Windows.Forms.Padding(3);
            this.tabTacGia.Size = new System.Drawing.Size(1174, 638);
            this.tabTacGia.TabIndex = 3;
            this.tabTacGia.Text = "Tác Giả";
            this.tabTacGia.UseVisualStyleBackColor = true;
            // 
            // panel40
            // 
            this.panel40.Controls.Add(this.panel41);
            this.panel40.Controls.Add(this.panel44);
            this.panel40.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel40.Location = new System.Drawing.Point(3, 3);
            this.panel40.Name = "panel40";
            this.panel40.Size = new System.Drawing.Size(1168, 632);
            this.panel40.TabIndex = 2;
            // 
            // panel41
            // 
            this.panel41.Controls.Add(this.panel42);
            this.panel41.Controls.Add(this.panel43);
            this.panel41.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel41.Location = new System.Drawing.Point(0, 0);
            this.panel41.Name = "panel41";
            this.panel41.Size = new System.Drawing.Size(740, 632);
            this.panel41.TabIndex = 0;
            // 
            // panel42
            // 
            this.panel42.Controls.Add(this.lsvTacGia);
            this.panel42.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel42.Location = new System.Drawing.Point(0, 49);
            this.panel42.Name = "panel42";
            this.panel42.Size = new System.Drawing.Size(740, 583);
            this.panel42.TabIndex = 1;
            // 
            // lsvTacGia
            // 
            this.lsvTacGia.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.clmMaTG,
            this.clmTenTG,
            this.clmSDT,
            this.clmDiaChi_TG});
            this.lsvTacGia.Dock = System.Windows.Forms.DockStyle.Fill;
            this.lsvTacGia.FullRowSelect = true;
            this.lsvTacGia.GridLines = true;
            this.lsvTacGia.HideSelection = false;
            this.lsvTacGia.Location = new System.Drawing.Point(0, 0);
            this.lsvTacGia.MultiSelect = false;
            this.lsvTacGia.Name = "lsvTacGia";
            this.lsvTacGia.Size = new System.Drawing.Size(740, 583);
            this.lsvTacGia.TabIndex = 0;
            this.lsvTacGia.TabStop = false;
            this.lsvTacGia.UseCompatibleStateImageBehavior = false;
            this.lsvTacGia.View = System.Windows.Forms.View.Details;
            this.lsvTacGia.ColumnClick += new System.Windows.Forms.ColumnClickEventHandler(this.lsvTacGia_ColumnClick);
            this.lsvTacGia.SelectedIndexChanged += new System.EventHandler(this.lsvTacGia_SelectedIndexChanged);
            // 
            // clmMaTG
            // 
            this.clmMaTG.Text = "Mã Tác Giả";
            this.clmMaTG.Width = 142;
            // 
            // clmTenTG
            // 
            this.clmTenTG.Text = "Tên Tác Giả";
            this.clmTenTG.Width = 260;
            // 
            // clmSDT
            // 
            this.clmSDT.Text = "Số Điện Thoại";
            this.clmSDT.Width = 170;
            // 
            // clmDiaChi_TG
            // 
            this.clmDiaChi_TG.Text = "Địa Chỉ";
            this.clmDiaChi_TG.Width = 250;
            // 
            // panel43
            // 
            this.panel43.Controls.Add(this.btnThemTG);
            this.panel43.Controls.Add(this.btnSuaTG);
            this.panel43.Controls.Add(this.btnXoaTG);
            this.panel43.Controls.Add(this.btnLMTG);
            this.panel43.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel43.Location = new System.Drawing.Point(0, 0);
            this.panel43.Name = "panel43";
            this.panel43.Size = new System.Drawing.Size(740, 49);
            this.panel43.TabIndex = 0;
            // 
            // btnThemTG
            // 
            this.btnThemTG.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnThemTG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnThemTG.FlatAppearance.BorderSize = 0;
            this.btnThemTG.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnThemTG.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnThemTG.ForeColor = System.Drawing.Color.White;
            this.btnThemTG.ImageIndex = 0;
            this.btnThemTG.ImageList = this.imgList;
            this.btnThemTG.Location = new System.Drawing.Point(264, 3);
            this.btnThemTG.Name = "btnThemTG";
            this.btnThemTG.Size = new System.Drawing.Size(113, 40);
            this.btnThemTG.TabIndex = 0;
            this.btnThemTG.Text = "Thêm";
            this.btnThemTG.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnThemTG.UseVisualStyleBackColor = false;
            this.btnThemTG.Click += new System.EventHandler(this.btnThemTG_Click);
            // 
            // btnSuaTG
            // 
            this.btnSuaTG.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnSuaTG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnSuaTG.FlatAppearance.BorderSize = 0;
            this.btnSuaTG.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSuaTG.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnSuaTG.ForeColor = System.Drawing.Color.White;
            this.btnSuaTG.ImageIndex = 1;
            this.btnSuaTG.ImageList = this.imgList;
            this.btnSuaTG.Location = new System.Drawing.Point(383, 3);
            this.btnSuaTG.Name = "btnSuaTG";
            this.btnSuaTG.Size = new System.Drawing.Size(113, 40);
            this.btnSuaTG.TabIndex = 1;
            this.btnSuaTG.Text = "Sửa";
            this.btnSuaTG.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnSuaTG.UseVisualStyleBackColor = false;
            this.btnSuaTG.Click += new System.EventHandler(this.btnSuaTG_Click);
            // 
            // btnXoaTG
            // 
            this.btnXoaTG.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnXoaTG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnXoaTG.FlatAppearance.BorderSize = 0;
            this.btnXoaTG.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnXoaTG.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnXoaTG.ForeColor = System.Drawing.Color.White;
            this.btnXoaTG.ImageIndex = 2;
            this.btnXoaTG.ImageList = this.imgList;
            this.btnXoaTG.Location = new System.Drawing.Point(502, 3);
            this.btnXoaTG.Name = "btnXoaTG";
            this.btnXoaTG.Size = new System.Drawing.Size(113, 40);
            this.btnXoaTG.TabIndex = 2;
            this.btnXoaTG.Text = "Xóa";
            this.btnXoaTG.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnXoaTG.UseVisualStyleBackColor = false;
            this.btnXoaTG.Click += new System.EventHandler(this.btnXoaTG_Click);
            // 
            // btnLMTG
            // 
            this.btnLMTG.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnLMTG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnLMTG.FlatAppearance.BorderSize = 0;
            this.btnLMTG.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnLMTG.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLMTG.ForeColor = System.Drawing.Color.White;
            this.btnLMTG.ImageIndex = 4;
            this.btnLMTG.ImageList = this.imgList;
            this.btnLMTG.Location = new System.Drawing.Point(621, 3);
            this.btnLMTG.Name = "btnLMTG";
            this.btnLMTG.Size = new System.Drawing.Size(113, 40);
            this.btnLMTG.TabIndex = 3;
            this.btnLMTG.Text = "Làm mới";
            this.btnLMTG.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnLMTG.UseVisualStyleBackColor = false;
            this.btnLMTG.Click += new System.EventHandler(this.btnLMTG_Click);
            // 
            // panel44
            // 
            this.panel44.Controls.Add(this.panel45);
            this.panel44.Controls.Add(this.panel50);
            this.panel44.Dock = System.Windows.Forms.DockStyle.Right;
            this.panel44.Location = new System.Drawing.Point(740, 0);
            this.panel44.Name = "panel44";
            this.panel44.Size = new System.Drawing.Size(428, 632);
            this.panel44.TabIndex = 1;
            // 
            // panel45
            // 
            this.panel45.Controls.Add(this.panel46);
            this.panel45.Controls.Add(this.panel49);
            this.panel45.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel45.Location = new System.Drawing.Point(0, 49);
            this.panel45.Name = "panel45";
            this.panel45.Size = new System.Drawing.Size(428, 583);
            this.panel45.TabIndex = 1;
            // 
            // panel46
            // 
            this.panel46.Controls.Add(this.panel52);
            this.panel46.Controls.Add(this.panel51);
            this.panel46.Controls.Add(this.panel47);
            this.panel46.Controls.Add(this.panel48);
            this.panel46.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel46.Location = new System.Drawing.Point(0, 45);
            this.panel46.Name = "panel46";
            this.panel46.Size = new System.Drawing.Size(428, 538);
            this.panel46.TabIndex = 0;
            // 
            // panel52
            // 
            this.panel52.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel52.Controls.Add(this.txtDiaChiTG);
            this.panel52.Controls.Add(this.label20);
            this.panel52.Location = new System.Drawing.Point(6, 169);
            this.panel52.Name = "panel52";
            this.panel52.Size = new System.Drawing.Size(416, 72);
            this.panel52.TabIndex = 3;
            // 
            // txtDiaChiTG
            // 
            this.txtDiaChiTG.Enabled = false;
            this.txtDiaChiTG.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiaChiTG.Location = new System.Drawing.Point(117, 3);
            this.txtDiaChiTG.Multiline = true;
            this.txtDiaChiTG.Name = "txtDiaChiTG";
            this.txtDiaChiTG.Size = new System.Drawing.Size(296, 66);
            this.txtDiaChiTG.TabIndex = 1;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(4, 7);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(75, 24);
            this.label20.TabIndex = 0;
            this.label20.Text = "Địa Chỉ:";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel51
            // 
            this.panel51.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel51.Controls.Add(this.txtSDT);
            this.panel51.Controls.Add(this.label19);
            this.panel51.Location = new System.Drawing.Point(6, 115);
            this.panel51.Name = "panel51";
            this.panel51.Size = new System.Drawing.Size(416, 38);
            this.panel51.TabIndex = 2;
            // 
            // txtSDT
            // 
            this.txtSDT.Enabled = false;
            this.txtSDT.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSDT.Location = new System.Drawing.Point(117, 3);
            this.txtSDT.Name = "txtSDT";
            this.txtSDT.Size = new System.Drawing.Size(296, 30);
            this.txtSDT.TabIndex = 1;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(4, 7);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(52, 24);
            this.label19.TabIndex = 0;
            this.label19.Text = "SĐT:";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel47
            // 
            this.panel47.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel47.Controls.Add(this.txtTenTG);
            this.panel47.Controls.Add(this.label13);
            this.panel47.Location = new System.Drawing.Point(6, 61);
            this.panel47.Name = "panel47";
            this.panel47.Size = new System.Drawing.Size(416, 38);
            this.panel47.TabIndex = 1;
            // 
            // txtTenTG
            // 
            this.txtTenTG.Enabled = false;
            this.txtTenTG.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTenTG.Location = new System.Drawing.Point(117, 3);
            this.txtTenTG.Name = "txtTenTG";
            this.txtTenTG.Size = new System.Drawing.Size(296, 30);
            this.txtTenTG.TabIndex = 1;
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(4, 7);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(80, 24);
            this.label13.TabIndex = 0;
            this.label13.Text = "Tên TG:";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel48
            // 
            this.panel48.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.panel48.Controls.Add(this.txtMaTG);
            this.panel48.Controls.Add(this.label14);
            this.panel48.Location = new System.Drawing.Point(6, 7);
            this.panel48.Name = "panel48";
            this.panel48.Size = new System.Drawing.Size(416, 38);
            this.panel48.TabIndex = 0;
            // 
            // txtMaTG
            // 
            this.txtMaTG.Enabled = false;
            this.txtMaTG.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtMaTG.Location = new System.Drawing.Point(117, 3);
            this.txtMaTG.Name = "txtMaTG";
            this.txtMaTG.Size = new System.Drawing.Size(296, 30);
            this.txtMaTG.TabIndex = 1;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(4, 7);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(72, 24);
            this.label14.TabIndex = 0;
            this.label14.Text = "Mã TG:";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel49
            // 
            this.panel49.Controls.Add(this.label15);
            this.panel49.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel49.Location = new System.Drawing.Point(0, 0);
            this.panel49.Name = "panel49";
            this.panel49.Size = new System.Drawing.Size(428, 45);
            this.panel49.TabIndex = 0;
            // 
            // label15
            // 
            this.label15.Dock = System.Windows.Forms.DockStyle.Fill;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(0, 0);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(428, 45);
            this.label15.TabIndex = 0;
            this.label15.Text = "Thông tin chi tiết";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // panel50
            // 
            this.panel50.Controls.Add(this.txtTimTG);
            this.panel50.Controls.Add(this.btnTimTG);
            this.panel50.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel50.Location = new System.Drawing.Point(0, 0);
            this.panel50.Name = "panel50";
            this.panel50.Size = new System.Drawing.Size(428, 49);
            this.panel50.TabIndex = 0;
            // 
            // txtTimTG
            // 
            this.txtTimTG.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtTimTG.Location = new System.Drawing.Point(14, 13);
            this.txtTimTG.Name = "txtTimTG";
            this.txtTimTG.Size = new System.Drawing.Size(292, 30);
            this.txtTimTG.TabIndex = 0;
            this.txtTimTG.TextChanged += new System.EventHandler(this.txtTimTG_TextChanged);
            // 
            // btnTimTG
            // 
            this.btnTimTG.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnTimTG.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(48)))), ((int)(((byte)(63)))), ((int)(((byte)(159)))));
            this.btnTimTG.FlatAppearance.BorderSize = 0;
            this.btnTimTG.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTimTG.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnTimTG.ForeColor = System.Drawing.Color.White;
            this.btnTimTG.ImageIndex = 3;
            this.btnTimTG.ImageList = this.imgList;
            this.btnTimTG.Location = new System.Drawing.Point(312, 3);
            this.btnTimTG.Name = "btnTimTG";
            this.btnTimTG.Size = new System.Drawing.Size(113, 40);
            this.btnTimTG.TabIndex = 1;
            this.btnTimTG.Text = "Tìm";
            this.btnTimTG.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btnTimTG.UseVisualStyleBackColor = false;
            this.btnTimTG.Click += new System.EventHandler(this.btnTimTG_Click);
            // 
            // frmSanPham
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1182, 673);
            this.Controls.Add(this.tabSanPham);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MinimumSize = new System.Drawing.Size(1200, 720);
            this.Name = "frmSanPham";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "QUẢN LÍ SẢN PHẨM";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.frmSanPham_Load);
            this.tabSanPham.ResumeLayout(false);
            this.tabSach.ResumeLayout(false);
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel7.ResumeLayout(false);
            this.panel9.ResumeLayout(false);
            this.panel17.ResumeLayout(false);
            this.panel17.PerformLayout();
            this.panel16.ResumeLayout(false);
            this.panel16.PerformLayout();
            this.panel15.ResumeLayout(false);
            this.panel15.PerformLayout();
            this.panel14.ResumeLayout(false);
            this.panel14.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numSoLuong)).EndInit();
            this.panel13.ResumeLayout(false);
            this.panel13.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numNamXB)).EndInit();
            this.panel12.ResumeLayout(false);
            this.panel12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numGiaBan)).EndInit();
            this.panel11.ResumeLayout(false);
            this.panel11.PerformLayout();
            this.panel10.ResumeLayout(false);
            this.panel10.PerformLayout();
            this.panel8.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel5.PerformLayout();
            this.tabNXB.ResumeLayout(false);
            this.panel18.ResumeLayout(false);
            this.panel19.ResumeLayout(false);
            this.panel20.ResumeLayout(false);
            this.panel21.ResumeLayout(false);
            this.panel22.ResumeLayout(false);
            this.panel23.ResumeLayout(false);
            this.panel24.ResumeLayout(false);
            this.panel53.ResumeLayout(false);
            this.panel53.PerformLayout();
            this.panel31.ResumeLayout(false);
            this.panel31.PerformLayout();
            this.panel32.ResumeLayout(false);
            this.panel32.PerformLayout();
            this.panel33.ResumeLayout(false);
            this.panel34.ResumeLayout(false);
            this.panel34.PerformLayout();
            this.tabTheLoai.ResumeLayout(false);
            this.panel25.ResumeLayout(false);
            this.panel26.ResumeLayout(false);
            this.panel27.ResumeLayout(false);
            this.panel28.ResumeLayout(false);
            this.panel29.ResumeLayout(false);
            this.panel30.ResumeLayout(false);
            this.panel35.ResumeLayout(false);
            this.panel36.ResumeLayout(false);
            this.panel36.PerformLayout();
            this.panel37.ResumeLayout(false);
            this.panel37.PerformLayout();
            this.panel38.ResumeLayout(false);
            this.panel39.ResumeLayout(false);
            this.panel39.PerformLayout();
            this.tabTacGia.ResumeLayout(false);
            this.panel40.ResumeLayout(false);
            this.panel41.ResumeLayout(false);
            this.panel42.ResumeLayout(false);
            this.panel43.ResumeLayout(false);
            this.panel44.ResumeLayout(false);
            this.panel45.ResumeLayout(false);
            this.panel46.ResumeLayout(false);
            this.panel52.ResumeLayout(false);
            this.panel52.PerformLayout();
            this.panel51.ResumeLayout(false);
            this.panel51.PerformLayout();
            this.panel47.ResumeLayout(false);
            this.panel47.PerformLayout();
            this.panel48.ResumeLayout(false);
            this.panel48.PerformLayout();
            this.panel49.ResumeLayout(false);
            this.panel50.ResumeLayout(false);
            this.panel50.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabSanPham;
        private System.Windows.Forms.TabPage tabSach;
        private System.Windows.Forms.TabPage tabNXB;
        private System.Windows.Forms.TabPage tabTheLoai;
        private System.Windows.Forms.TabPage tabTacGia;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button btnLMSach;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel7;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Button btnThemSach;
        private System.Windows.Forms.Button btnSuaSach;
        private System.Windows.Forms.Button btnXoaSach;
        private System.Windows.Forms.Button btnTimSach;
        private System.Windows.Forms.ColumnHeader clmMaSach;
        private System.Windows.Forms.ColumnHeader clmTenSach;
        private System.Windows.Forms.ColumnHeader clmGiaBan;
        private System.Windows.Forms.ColumnHeader clmNamXB;
        private System.Windows.Forms.ColumnHeader clmSoLuongTon;
        private System.Windows.Forms.ColumnHeader clmNXB;
        private System.Windows.Forms.ColumnHeader clmTheLoai;
        private System.Windows.Forms.ColumnHeader clmTacGia;
        private System.Windows.Forms.Panel panel8;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel9;
        private System.Windows.Forms.Panel panel10;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtMaSach;
        private System.Windows.Forms.Panel panel13;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel12;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Panel panel11;
        private System.Windows.Forms.TextBox txtTenSach;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.NumericUpDown numGiaBan;
        private System.Windows.Forms.Panel panel14;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel15;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.ComboBox cmbTL;
        private System.Windows.Forms.Panel panel16;
        private System.Windows.Forms.ComboBox cmbNXB;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Panel panel17;
        private System.Windows.Forms.ComboBox cmbTG;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.NumericUpDown numSoLuong;
        private System.Windows.Forms.NumericUpDown numNamXB;
        private System.Windows.Forms.ImageList imgList;
        private System.Windows.Forms.TextBox txtTimSach;
        private System.Windows.Forms.Panel panel18;
        private System.Windows.Forms.Panel panel19;
        private System.Windows.Forms.Panel panel20;
        private System.Windows.Forms.ListView lsvNXB;
        private System.Windows.Forms.ColumnHeader clmMaNXB;
        private System.Windows.Forms.ColumnHeader clmTenNXB;
        private System.Windows.Forms.Panel panel21;
        private System.Windows.Forms.Button btnThemNXB;
        private System.Windows.Forms.Button btnSuaNXB;
        private System.Windows.Forms.Button btnXoaNXB;
        private System.Windows.Forms.Button btnLMNXB;
        private System.Windows.Forms.Panel panel22;
        private System.Windows.Forms.Panel panel23;
        private System.Windows.Forms.Panel panel24;
        private System.Windows.Forms.Panel panel31;
        private System.Windows.Forms.TextBox txtTenNXB;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Panel panel32;
        private System.Windows.Forms.TextBox txtMaNXB;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Panel panel33;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Panel panel34;
        private System.Windows.Forms.TextBox txtTimNXB;
        private System.Windows.Forms.Button btnTimNXB;
        private System.Windows.Forms.Panel panel25;
        private System.Windows.Forms.Panel panel26;
        private System.Windows.Forms.Panel panel27;
        private System.Windows.Forms.ListView lsvTheLoai;
        private System.Windows.Forms.ColumnHeader clmMaTL;
        private System.Windows.Forms.ColumnHeader clmTenTL;
        private System.Windows.Forms.Panel panel28;
        private System.Windows.Forms.Button btnThemTL;
        private System.Windows.Forms.Button btnSuaTL;
        private System.Windows.Forms.Button btnXoaTL;
        private System.Windows.Forms.Button btnLMTL;
        private System.Windows.Forms.Panel panel29;
        private System.Windows.Forms.Panel panel30;
        private System.Windows.Forms.Panel panel35;
        private System.Windows.Forms.Panel panel36;
        private System.Windows.Forms.TextBox txtTenTL;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Panel panel37;
        private System.Windows.Forms.TextBox txtMaTL;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Panel panel38;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Panel panel39;
        private System.Windows.Forms.TextBox txtTimTL;
        private System.Windows.Forms.Button btnTimTL;
        private System.Windows.Forms.Panel panel40;
        private System.Windows.Forms.Panel panel41;
        private System.Windows.Forms.Panel panel42;
        private System.Windows.Forms.ListView lsvTacGia;
        private System.Windows.Forms.ColumnHeader clmMaTG;
        private System.Windows.Forms.ColumnHeader clmTenTG;
        private System.Windows.Forms.Panel panel43;
        private System.Windows.Forms.Button btnThemTG;
        private System.Windows.Forms.Button btnSuaTG;
        private System.Windows.Forms.Button btnXoaTG;
        private System.Windows.Forms.Button btnLMTG;
        private System.Windows.Forms.Panel panel44;
        private System.Windows.Forms.Panel panel45;
        private System.Windows.Forms.Panel panel46;
        private System.Windows.Forms.Panel panel47;
        private System.Windows.Forms.TextBox txtTenTG;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Panel panel48;
        private System.Windows.Forms.TextBox txtMaTG;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Panel panel49;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Panel panel50;
        private System.Windows.Forms.TextBox txtTimTG;
        private System.Windows.Forms.Button btnTimTG;
        private System.Windows.Forms.ListView lsvSach;
        private System.Windows.Forms.ColumnHeader clmDiaChi;
        private System.Windows.Forms.ColumnHeader clmSDT;
        private System.Windows.Forms.ColumnHeader clmDiaChi_TG;
        private System.Windows.Forms.Panel panel52;
        private System.Windows.Forms.TextBox txtDiaChiTG;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Panel panel51;
        private System.Windows.Forms.TextBox txtSDT;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Panel panel53;
        private System.Windows.Forms.TextBox txtDiaChi;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Button btnXuatSach;
    }
}