# BookShop-Winforms
Phần mềm quản lí Cửa hàng bán sách: Quản lí bán, xuất nhập hóa đơn, bán cáo doanh thu, ...

Hướng dẫn sử dụng:

-> Yêu cầu:
    * Sql server 2017
    * Net framework 4.5
